`timescale 1ns/1ps
module tb_displays;
    reg [7:0] value=0;
    reg hex_mode=0;
    wire [3:0] d1,d2,d3;
    wire [2:0] blanks;
    display_formatter fmt(.value(value),.hex_mode(hex_mode),.digit_c1(d1),
        .digit_c2(d2),.digit_c3(d3),.blank(blanks));
    reg [3:0] digit=0;
    reg blank=0,dp=0,operator_mode=0;
    reg [1:0] op=0;
    wire [7:0] c1,c1n,c2,c2n;
    wire [16:0] c3,c3n;
    c1_display #(.ACTIVE_LOW(0)) u1(digit,blank,dp,c1);
    c1_display #(.ACTIVE_LOW(1)) u1n(digit,blank,dp,c1n);
    c2_display #(.ACTIVE_LOW(0)) u2(digit,blank,dp,c2);
    c2_display #(.ACTIVE_LOW(1)) u2n(digit,blank,dp,c2n);
    c3_display #(.ACTIVE_LOW(0)) u3(digit,blank,dp,operator_mode,op,c3);
    c3_display #(.ACTIVE_LOW(1)) u3n(digit,blank,dp,operator_mode,op,c3n);
    reg [7:0] seven[0:15];
    reg [16:0] star[0:15];
    reg [16:0] symbols[0:3];
    integer i;
    initial begin
        seven[0]='h3F; seven[1]='h06; seven[2]='h5B; seven[3]='h4F;
        seven[4]='h66; seven[5]='h6D; seven[6]='h7D; seven[7]='h07;
        seven[8]='h7F; seven[9]='h6F; seven[10]='h77; seven[11]='h7C;
        seven[12]='h39; seven[13]='h5E; seven[14]='h79; seven[15]='h71;
        star[0]='h0FF; star[1]='h00C; star[2]='h377; star[3]='h33F;
        star[4]='h38C; star[5]='h3BB; star[6]='h3FB; star[7]='h00F;
        star[8]='h3FF; star[9]='h3BF; star[10]='h3CF; star[11]='h3F8;
        star[12]='h0F3; star[13]='h37C; star[14]='h3F3; star[15]='h3C3;
        symbols[0]='h4B00; symbols[1]='h300; symbols[2]='hB400; symbols[3]='h9000;
        for(i=0;i<256;i=i+1) begin
            value=i; hex_mode=0; #1;
            if(d1!==i/100 || d2!==(i/10)%10 || d3!==i%10 ||
               blanks[0]!==(i<100) || blanks[1]!==(i<10) || blanks[2]!==0)
                $fatal(1,"Decimal formatter value=%0d",i);
            hex_mode=1; #1;
            if(d1!==i/16 || d2!==i%16 || blanks!==3'b100)
                $fatal(1,"Hex formatter value=%0d",i);
        end
        for(i=0;i<16;i=i+1) begin
            digit=i; dp=0; #1;
            if(c1!==seven[i] || c2!==seven[i] || c3!==star[i] ||
               c1n!==~c1 || c2n!==~c2 || c3n!==~c3) $fatal(1,"Digit %0d mapping",i);
            dp=1; #1;
            if(c1!==(seven[i]|8'h80) || c2!==c1 || c3!==(star[i]|17'h10000))
                $fatal(1,"Digit %0d decimal point",i);
        end
        dp=0; operator_mode=1;
        for(i=0;i<4;i=i+1) begin
            op=i; #1;
            if(c3!==symbols[i] || c3n!==~symbols[i]) $fatal(1,"Operator %0d",i);
        end
        blank=1; dp=1; #1;
        if(c1!==0 || c2!==0 || c3!==0 || c1n!==8'hFF || c2n!==8'hFF || c3n!==17'h1FFFF)
            $fatal(1,"Blank must override digit and DP");
        $display("PASS displays: all 256 decimal/hex values, 16 glyphs, polarities, DP, blank and operators");
        $finish;
    end
endmodule
