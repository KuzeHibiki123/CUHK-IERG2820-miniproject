`timescale 1ns/1ps
// All logic uses clk. step_ce is sampled on the very edge that raises CCLK.
// CCLK is an oscilloscope output; it is NOT used as an internal clock.
module clock_enable #(
    parameter CLOCK_HZ = 50000000,
    parameter STEP_HZ = 10
) (
    input wire clk,
    input wire reset,
    output reg cclk,
    output wire step_ce
);
    localparam HALF_PERIOD = CLOCK_HZ / (2 * STEP_HZ);
    localparam COUNT_WIDTH = (HALF_PERIOD < 2) ? 1 : $clog2(HALF_PERIOD);
    reg [COUNT_WIDTH-1:0] count;
    assign step_ce = !reset && !cclk && (count == HALF_PERIOD - 1);
    always @(posedge clk) begin
        if (reset) begin
            count <= 0;
            cclk <= 0;
        end else if (count == HALF_PERIOD - 1) begin
            count <= 0;
            cclk <= ~cclk;
        end else begin
            count <= count + 1'b1;
        end
    end
endmodule
