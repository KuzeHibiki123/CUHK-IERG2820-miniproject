`timescale 1ns/1ps
module tb_display_startup;
 reg clk=0, clock_run=1;
 always #10 if(clock_run) clk=~clk;
 reg [1:12] t=0; reg [1:4] k=0;
 wire [1:16] led; wire [7:0] c1,c2; wire [16:0] c3; wire cc;
 mini_project_top #(.DEBOUNCE_CYCLES(3)) dut(clk,t,k,1'b0,1'b0,led,c1,c2,c3,cc);
 task ticks; input integer n; begin repeat(n) begin @(posedge clk); #1; end end endtask
 initial begin
  ticks(12);
  if(c1!==8'h3f || c2!==8'h3f || c3!==17'h04b00) $fatal(1,"Q1 power-up must show 0,0,+");
  @(negedge clk); k[4]=1; ticks(8);
  if(c1!==0 || c2!==0 || c3!==0) $fatal(1,"High K4 must reproduce blank display");
  @(negedge clk); clock_run=0; k[4]=0; #200;
  if(c1!==0 || c2!==0 || c3!==0) $fatal(1,"No clock must retain blank outputs");
  clock_run=1; ticks(12);
  if(c1!==8'h3f || c2!==8'h3f || c3!==17'h04b00) $fatal(1,"Clock and reset recovery");
  $display("PASS current defaults: power-up 0/0/+, K4-high blanks all displays, missing clock prevents recovery"); $finish;
 end
endmodule
