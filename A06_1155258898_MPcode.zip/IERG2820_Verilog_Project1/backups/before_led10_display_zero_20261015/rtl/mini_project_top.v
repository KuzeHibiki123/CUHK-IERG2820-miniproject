`timescale 1ns/1ps
// Top-level board-independent wiring. Assign actual FPGA package pins in Quartus.
// T[1] is T1, K[1] is K1, LED[1] is LED1, etc.
module mini_project_top #(
    parameter CLOCK_HZ = 50000000,
    parameter CPU_HZ = 1, // Slow mode; K2 selects this or the full input rate.
    parameter DEBOUNCE_CYCLES = 500000, // 10 ms at 50 MHz
    parameter TOUCH_ACTIVE_LOW = 0,
    parameter KEY_ACTIVE_LOW = 0,
    parameter SW1_ACTIVE_LOW = 0, // Pressed high: one execute pulse after debounce.
    parameter SW2_Q2_LEVEL = 1,
    parameter LED_ACTIVE_LOW = 0,
    parameter C1_ACTIVE_LOW = 0,
    parameter C2_ACTIVE_LOW = 0,
    parameter C3_ACTIVE_LOW = 0,
    parameter Q1_CHAIN_8BIT = 0, // Lab rule: repeat with only result[3:0].
    parameter SHARE_MATH = 0
) (
    input wire CLK_50,
    input wire [1:12] T,
    input wire [1:4] K,
    input wire SW1,
    input wire SW2,
    output wire [1:16] LED,
    output wire [7:0] C1,
    output wire [7:0] C2,
    output wire [16:0] C3,
    output wire CCLK
);
    wire [1:12] touch_raw = TOUCH_ACTIVE_LOW ? ~T : T;
    wire [1:4] key_raw = KEY_ACTIVE_LOW ? ~K : K;
    wire execute_raw = SW1_ACTIVE_LOW ? ~SW1 : SW1;
    wire mode_raw = (SW2 == SW2_Q2_LEVEL);
    // Configuration-time initialization only; no external reset control.
    // K3/K4 are unused, so an unconnected K4 cannot blank the display.
    reg [1:0] reset_pipe = 2'b11;
    always @(posedge CLK_50) begin
        reset_pipe <= {reset_pipe[0], 1'b0};
    end
    wire reset = reset_pipe[1];
    wire [1:12] touch;
    wire sw1_level, execute_pulse, mode_q2, k1_level, k1_pulse;
    input_filter #(.WIDTH(12), .STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_t
        (.clk(CLK_50), .reset(reset), .async_in(touch_raw), .level(touch), .rise());
    input_filter #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_sw1
        (.clk(CLK_50), .reset(reset), .async_in(execute_raw),
         .level(sw1_level), .rise(execute_pulse));
    input_filter #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_mode
        (.clk(CLK_50), .reset(reset), .async_in(mode_raw), .level(mode_q2), .rise());
    input_filter #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_k1
        (.clk(CLK_50), .reset(reset), .async_in(key_raw[1]),
         .level(k1_level), .rise(k1_pulse));
    wire k2_pulse;
    reg slow_mode;
    input_filter #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_k2
        (.clk(CLK_50), .reset(reset), .async_in(key_raw[2]),
         .level(), .rise(k2_pulse));
    always @(posedge CLK_50) begin
        if (reset) slow_mode <= 0;
        else if (k2_pulse) slow_mode <= ~slow_mode;
    end
    wire step_ce;
    selectable_clock_enable #(.CLOCK_HZ(CLOCK_HZ), .STEP_HZ(CPU_HZ)) slow_clock
        (.clk(CLK_50), .reset(reset), .slow_mode(slow_mode),
         .cclk(CCLK), .step_ce(step_ce));
    // Low-numbered data keys are LSBs; opcode keys are read left to right.
    wire [3:0] group_a = {touch[4],touch[3],touch[2],touch[1]};
    wire [3:0] group_b = {touch[8],touch[7],touch[6],touch[5]};
    wire [1:0] q1_operator = {touch[9],touch[10]};
    wire [7:0] data_in = {group_b,group_a};
    wire [3:0] opcode = {touch[9],touch[10],touch[11],touch[12]};
    wire [7:0] q1_result, q2_result, q2_display;
    wire q1_carry, q1_error, q1_show;
    wire q2_carry, q2_zero, q2_error, q2_busy;
    wire [7:0] q1_math_lhs,q2_a,q2_b;
    wire [15:0] math_product;
    wire [7:0] math_quotient;
    wire [7:0] q2_math_quotient;
    generate if (SHARE_MATH) begin: shared_math
        // Share multiplication. Separate division avoids the operand-select
        // mux ahead of the longest combinational path at 50 MHz.
        wire [7:0] lhs = mode_q2 ? q2_a : q1_math_lhs;
        wire [7:0] rhs = mode_q2 ? q2_b : {4'b0,group_b};
        assign math_product = lhs * rhs;
        if (Q1_CHAIN_8BIT) begin: wide_q1_divider
            assign math_quotient = q1_math_lhs / group_b;
        end else begin: nibble_q1_divider
            wire [3:0] quotient = q1_math_lhs[3:0] / group_b;
            assign math_quotient = {4'b0, quotient};
        end
        assign q2_math_quotient = q2_a / q2_b;
    end else begin: separate_math
        assign math_product = 0;
        assign math_quotient = 0;
        assign q2_math_quotient = 0;
    end endgenerate
    question1 #(.CHAIN_8BIT(Q1_CHAIN_8BIT),.EXTERNAL_MATH(SHARE_MATH)) q1
        (.clk(CLK_50), .reset(reset), .enable(!mode_q2), .execute(execute_pulse),
         .group_a(group_a), .group_b(group_b), .operator_code(q1_operator),
         .result(q1_result), .carry_borrow(q1_carry), .error(q1_error),
         .show_result(q1_show), .math_product(math_product),
         .math_quotient(math_quotient), .math_lhs(q1_math_lhs));
    question2 #(.EXTERNAL_MATH(SHARE_MATH)) q2
        (.clk(CLK_50), .reset(reset), .enable(mode_q2), .step_ce(step_ce),
         .execute(execute_pulse), .data_in(data_in), .opcode(opcode),
         .reg_a(q2_a), .reg_b(q2_b), .reg_c(), .result(q2_result),
         .carry_borrow(q2_carry), .zero(q2_zero), .error(q2_error),
         .display_value(q2_display), .busy(q2_busy),
         .math_product(math_product), .math_quotient(q2_math_quotient));
    reg q2_hex_mode;
    always @(posedge CLK_50) begin
        if (reset) q2_hex_mode <= 0;
        else if (mode_q2 && k1_pulse) q2_hex_mode <= ~q2_hex_mode;
    end
    wire hex_mode = mode_q2 ? q2_hex_mode : touch[11];
    wire [7:0] display_value = mode_q2 ? q2_display : q1_result;
    wire preview = !mode_q2 && !q1_show;
    wire [7:0] display_input = preview ? {group_b,group_a} : display_value;
    c1_registered_display #(.ACTIVE_LOW(C1_ACTIVE_LOW)) display_c1
        (CLK_50,reset,display_input,hex_mode,preview,C1);
    c2_registered_display #(.ACTIVE_LOW(C2_ACTIVE_LOW)) display_c2
        (CLK_50,reset,display_input,hex_mode,preview,C2);
    c3_registered_display #(.ACTIVE_LOW(C3_ACTIVE_LOW)) display_c3
        (CLK_50,reset,display_input,hex_mode,preview,q1_operator,C3);
    // The ROM displays sample their value on this same edge. Delay Q2's
    // binary LEDs equally so they show the selected register in lockstep.
    reg [7:0] q2_led_display;
    always @(posedge CLK_50) begin
        if (reset) q2_led_display <= 0;
        else q2_led_display <= q2_display;
    end
    wire [7:0] led_result = mode_q2 ? q2_led_display : q1_result;
    wire [1:16] led_on;
    genvar i;
    generate for (i=1; i<=8; i=i+1) begin: led_bits
        assign led_on[i] = led_result[i-1];
    end endgenerate
    assign led_on[9] = mode_q2 ? q2_carry : q1_carry;
    assign led_on[10] = mode_q2 ? q2_zero : 1'b0;
    assign led_on[11:14] = 4'b0;
    assign led_on[15] = mode_q2 && q2_busy; // Optional pending-command indicator.
    assign led_on[16] = mode_q2 ? q2_error : q1_error;
    assign LED = LED_ACTIVE_LOW ? ~led_on : led_on;
endmodule
