`timescale 1ns/1ps
module tb_q2_led_display;
 reg clk=0; always #10 clk=~clk;
 reg [1:12] t=0; reg [1:4] k=0; reg sw1=0,sw2=1;
 wire [1:16] led; wire [7:0] c1,c2; wire [16:0] c3; wire cc;
 mini_project_top #(.CLOCK_HZ(200),.DEBOUNCE_CYCLES(3)) dut
  (clk,t,k,sw1,sw2,led,c1,c2,c3,cc);
 reg [7:0] seven[0:15];reg [16:0] star[0:9];
 reg sampled_mode,sampled_hex;
 reg [7:0] binary;
 reg [7:0] want1,want2;reg [16:0] want3;
 integer n,checks=0;
 always @(posedge clk)begin
  sampled_mode=dut.mode_q2;sampled_hex=dut.q2_hex_mode;
  #2;
  if(sampled_mode && dut.mode_q2 && !dut.reset)begin
   for(n=0;n<8;n=n+1)binary[n]=led[n+1];
   want1=sampled_hex?seven[binary/16]:((binary<100)?0:seven[binary/100]);
   want2=seven[sampled_hex?(binary%16):(binary%10)];
   want3=(sampled_hex||binary<10)?0:star[(binary/10)%10];
   if(c1!==want1||c2!==want2||c3!==want3)$fatal(1,"LED/display mismatch at %0t binary=%0d",$time,binary);
   checks=checks+1;
  end
 end
 task ticks;input integer count;begin repeat(count)begin @(posedge clk);#3;end end endtask
 task issue;input [3:0] op;input [7:0] data;input [7:0] expected;integer j;reg [7:0] actual;begin
  @(negedge clk);for(j=0;j<8;j=j+1)t[j+1]=data[j];
  t[9:12]=op;ticks(12);
  @(negedge clk);sw1=1;ticks(12);@(negedge clk);sw1=0;ticks(220);
  for(j=0;j<8;j=j+1)actual[j]=led[j+1];
  if(actual!==expected)$fatal(1,"Opcode %h expected displayed register=%0d actual=%0d",op,expected,actual);
 end endtask
 task key;input integer index;begin
  @(negedge clk);k[index]=1;ticks(12);@(negedge clk);k[index]=0;ticks(12);
 end endtask
 initial begin
  seven[0]='h3f;seven[1]='h06;seven[2]='h5b;seven[3]='h4f;seven[4]='h66;seven[5]='h6d;seven[6]='h7d;seven[7]='h07;
  seven[8]='h7f;seven[9]='h6f;seven[10]='h77;seven[11]='h7c;seven[12]='h39;seven[13]='h5e;seven[14]='h79;seven[15]='h71;
  star[0]='hff;star[1]='hc;star[2]='h377;star[3]='h33f;star[4]='h38c;star[5]='h3bb;star[6]='h3fb;star[7]='hf;star[8]='h3ff;star[9]='h3bf;
  ticks(20);
  issue(0,42,42);issue(1,99,42);issue(2,17,42);
  issue(13,0,99);issue(2,18,99);issue(4,0,99); // A=141; display remains B.
  issue(12,0,141);issue(1,2,141);issue(8,0,26); // A=26, B=1.
  issue(13,0,1);issue(9,0,1);issue(15,0,1);
  issue(14,0,18);issue(3,0,18); // A changes, selected C does not.
  key(1);issue(0,255,18);issue(12,0,255); // Hex FF, binary still 255.
  key(1);key(2);issue(1,3,255);issue(13,0,3); // Slow mode follows selected B.
  issue(2,225,3);issue(14,0,225);key(4);ticks(20);
  if(checks<1000)$fatal(1,"Insufficient transition coverage");
  $display("PASS Q2 LED/display: %0d cycle checks, default A, LOAD B/C, OUT A/B/C, sticky selection, arithmetic, NOP, decimal/hex and slow clock",checks);
  $finish;
 end
 initial begin #300000;$fatal(1,"Timeout");end
endmodule
