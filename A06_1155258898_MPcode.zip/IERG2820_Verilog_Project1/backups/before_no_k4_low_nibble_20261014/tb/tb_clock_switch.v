`timescale 1ns/1ps
module tb_clock_switch;
 reg clk=0; always #10 clk=~clk;
 reg [1:12] t=0; reg [1:4] k=0; reg sw1=0,sw2=1;
 wire [1:16] led; wire [7:0] c1,c2; wire [16:0] c3; wire cc;
 mini_project_top #(.CLOCK_HZ(1000),.DEBOUNCE_CYCLES(3)) dut
  (clk,t,k,sw1,sw2,led,c1,c2,c3,cc);
 integer cycles=0,last_rise=-1,rises=0;
 reg ce;
 always @(posedge clk) begin
  cycles=cycles+1; ce=dut.step_ce;
  if(dut.reset || dut.slow_clock.fast_selected) last_rise=-1;
  else if(ce) begin
   if(last_rise>=0 && cycles-last_rise!=1000) $fatal(1,"Not 1 Hz at scaled 1000 Hz input");
   last_rise=cycles; rises=rises+1;
  end
  #1;
  if(!dut.reset && ce && cc!==1) $fatal(1,"Execution not aligned with CCLK rise");
 end
 // Every observable rising edge must coincide with an input rising edge.
 always @(posedge cc) if($time>100 && clk!==1) $fatal(1,"Spurious CCLK rise");
 task ticks; input integer n; begin repeat(n) begin @(posedge clk); #2; end end endtask
 task key2; begin @(negedge clk); k[2]=1; ticks(12); @(negedge clk);k[2]=0;ticks(12);end endtask
 task load_a; input [7:0] v; integer n; begin
  @(negedge clk);for(n=0;n<8;n=n+1)t[n+1]=v[n];t[9:12]=0;ticks(12);
  @(negedge clk);sw1=1;ticks(12);@(negedge clk);sw1=0;ticks(12);
 end endtask
 initial begin
  ticks(20);
  if(dut.slow_mode!==0 || dut.slow_clock.fast_selected!==1) $fatal(1,"Default must be fast");
  repeat(10) begin @(negedge clk);#1;if(cc!==0)$fatal(1,"Fast falling edge");@(posedge clk);#1;if(cc!==1)$fatal(1,"Fast rising edge");end
  load_a(21);if(dut.q2_a!==21 || dut.q2_busy) $fatal(1,"Fast execute");
  // A one-cycle touch is noise, not a toggle.
  @(negedge clk);k[2]=1;ticks(1);@(negedge clk);k[2]=0;ticks(12);
  if(dut.slow_mode!==0)$fatal(1,"K2 bounce toggled");
  @(negedge clk);k[2]=1;ticks(2200);
  if(dut.slow_mode!==1 || rises<2)$fatal(1,"Held K2 repeated or slow rate wrong");
  @(negedge clk);k[2]=0;ticks(12);
  // Submit just after a slow falling edge: command must wait for the next rise.
  @(negedge cc);load_a(42);
  if(!dut.q2_busy || dut.q2_a!==21)$fatal(1,"Slow command did not wait");
  @(posedge cc);#3;if(dut.q2_a!==42)$fatal(1,"Slow command failed");
  // Queued command must survive switching back to fast, exactly once.
  @(negedge cc);load_a(73);
  if(!dut.q2_busy)$fatal(1,"Missing queued command");
  key2;
  if(dut.slow_mode!==0 || dut.q2_busy || dut.q2_a!==73)$fatal(1,"Switch to fast lost queued command");
  key2;if(dut.slow_mode!==1)$fatal(1,"Third touch must select slow");
  @(negedge clk);k[4]=1;ticks(6);@(negedge clk);k[4]=0;ticks(12);
  if(dut.slow_mode!==0 || dut.q2_a!==0 || dut.slow_clock.fast_selected!==1)$fatal(1,"Reset must restore fast");
  $display("PASS clock switch: fast default, 1 Hz period, K2 debounce/hold/toggle, CCLK edge alignment, pending instruction, reset");
  $finish;
 end
 initial begin #200000;$fatal(1,"Clock switch timeout");end
endmodule
