// Original top-level for regression, simulation only.
`timescale 1ns/1ps
// Top-level board-independent wiring. Assign actual FPGA package pins in Quartus.
// T[1] is T1, K[1] is K1, LED[1] is LED1, etc.
module reference_mini_project_top #(
    parameter CLOCK_HZ = 50000000,
    parameter CPU_HZ = 10,
    parameter DEBOUNCE_CYCLES = 500000, // 10 ms at 50 MHz
    parameter TOUCH_ACTIVE_LOW = 0,
    parameter KEY_ACTIVE_LOW = 0,
    parameter SW1_ACTIVE_LOW = 0, // Pressed high: one execute pulse after debounce.
    parameter SW2_Q2_LEVEL = 1,
    parameter LED_ACTIVE_LOW = 0,
    parameter C1_ACTIVE_LOW = 1,
    parameter C2_ACTIVE_LOW = 1,
    parameter C3_ACTIVE_LOW = 1,
    parameter Q1_CHAIN_8BIT = 0
) (
    input wire CLK_50,
    input wire [1:12] T,
    input wire [1:4] K,
    input wire SW1,
    input wire SW2,
    output wire [1:16] LED,
    output wire [7:0] C1,
    output wire [7:0] C2,
    output wire [16:0] C3,
    output wire CCLK
);
    wire [1:12] touch_raw = TOUCH_ACTIVE_LOW ? ~T : T;
    wire [1:4] key_raw = KEY_ACTIVE_LOW ? ~K : K;
    wire execute_raw = SW1_ACTIVE_LOW ? ~SW1 : SW1;
    wire mode_raw = (SW2 == SW2_Q2_LEVEL);
    // K4 is a reset extension. Async assertion, 2-clock synchronous release.
    // Initialization also supplies a power-up reset in Intel/Altera FPGAs.
    reg [1:0] reset_pipe = 2'b11;
    always @(posedge CLK_50 or posedge key_raw[4]) begin
        if (key_raw[4]) reset_pipe <= 2'b11;
        else reset_pipe <= {reset_pipe[0], 1'b0};
    end
    wire reset = reset_pipe[1];
    wire [1:12] touch;
    wire sw1_level, execute_pulse, mode_q2, k1_level, k1_pulse;
    reference_input_filter #(.WIDTH(12), .STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_t
        (.clk(CLK_50), .reset(reset), .async_in(touch_raw), .level(touch), .rise());
    reference_input_filter #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_sw1
        (.clk(CLK_50), .reset(reset), .async_in(execute_raw),
         .level(sw1_level), .rise(execute_pulse));
    reference_input_filter #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_mode
        (.clk(CLK_50), .reset(reset), .async_in(mode_raw), .level(mode_q2), .rise());
    reference_input_filter #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_k1
        (.clk(CLK_50), .reset(reset), .async_in(key_raw[1]),
         .level(k1_level), .rise(k1_pulse));
    wire step_ce;
    // Arithmetic regression uses the new default full-rate schedule.
    // K2 switching is checked separately by tb_clock_switch.
    assign step_ce = !reset;
    assign CCLK = CLK_50;
    // Low-numbered data keys are LSBs; opcode keys are read left to right.
    wire [3:0] group_a = {touch[4],touch[3],touch[2],touch[1]};
    wire [3:0] group_b = {touch[8],touch[7],touch[6],touch[5]};
    wire [1:0] q1_operator = {touch[9],touch[10]};
    wire [7:0] data_in = {group_b,group_a};
    wire [3:0] opcode = {touch[9],touch[10],touch[11],touch[12]};
    wire [7:0] q1_result, q2_result, q2_display;
    wire q1_carry, q1_error, q1_show;
    wire q2_carry, q2_zero, q2_error, q2_busy;
    reference_question1 #(.CHAIN_8BIT(Q1_CHAIN_8BIT)) q1
        (.clk(CLK_50), .reset(reset), .enable(!mode_q2), .execute(execute_pulse),
         .group_a(group_a), .group_b(group_b), .operator_code(q1_operator),
         .result(q1_result), .carry_borrow(q1_carry), .error(q1_error),
         .show_result(q1_show));
    reference_question2 q2
        (.clk(CLK_50), .reset(reset), .enable(mode_q2), .step_ce(step_ce),
         .execute(execute_pulse), .data_in(data_in), .opcode(opcode),
         .reg_a(), .reg_b(), .reg_c(), .result(q2_result),
         .carry_borrow(q2_carry), .zero(q2_zero), .error(q2_error),
         .display_value(q2_display), .busy(q2_busy));
    reg q2_hex_mode;
    always @(posedge CLK_50) begin
        if (reset) q2_hex_mode <= 0;
        else if (mode_q2 && k1_pulse) q2_hex_mode <= ~q2_hex_mode;
    end
    wire hex_mode = mode_q2 ? q2_hex_mode : touch[11];
    wire [7:0] display_value = mode_q2 ? q2_display : q1_result;
    wire [3:0] result_c1, result_c2, result_c3;
    wire [2:0] result_blank;
    display_formatter formatter (.value(display_value), .hex_mode(hex_mode),
        .digit_c1(result_c1), .digit_c2(result_c2), .digit_c3(result_c3),
        .blank(result_blank));
    reg [3:0] digit_c1, digit_c2, digit_c3;
    reg [2:0] blank;
    reg dp_c1, dp_c2, operator_mode;
    always @* begin
        digit_c1 = result_c1;
        digit_c2 = result_c2;
        digit_c3 = result_c3;
        blank = result_blank;
        dp_c1 = 0;
        dp_c2 = 0;
        operator_mode = 0;
        if (!mode_q2 && !q1_show) begin
            // User convention: decimal 10..15 -> units digit + lit DP.
            digit_c1 = (!hex_mode && group_a >= 10) ? group_a - 4'd10 : group_a;
            digit_c2 = (!hex_mode && group_b >= 10) ? group_b - 4'd10 : group_b;
            dp_c1 = !hex_mode && (group_a >= 10);
            dp_c2 = !hex_mode && (group_b >= 10);
            blank = 0;
            operator_mode = 1;
        end
    end
    wire [7:0] next_c1, next_c2;
    wire [16:0] next_c3;
    c1_display #(.ACTIVE_LOW(C1_ACTIVE_LOW)) display_c1
        (.digit(digit_c1), .blank(blank[0]), .decimal_point(dp_c1), .seg(next_c1));
    c2_display #(.ACTIVE_LOW(C2_ACTIVE_LOW)) display_c2
        (.digit(digit_c2), .blank(blank[1]), .decimal_point(dp_c2), .seg(next_c2));
    c3_display #(.ACTIVE_LOW(C3_ACTIVE_LOW)) display_c3
        (.digit(digit_c3), .blank(blank[2]), .decimal_point(1'b0),
         .operator_mode(operator_mode), .operator_code(q1_operator), .seg(next_c3));
    // Registered segment outputs avoid combinational display glitches.
    reg [7:0] c1_reg, c2_reg;
    reg [16:0] c3_reg;
    always @(posedge CLK_50) begin
        if (reset) begin
            c1_reg <= C1_ACTIVE_LOW ? 8'hFF : 8'h00;
            c2_reg <= C2_ACTIVE_LOW ? 8'hFF : 8'h00;
            c3_reg <= C3_ACTIVE_LOW ? 17'h1FFFF : 17'h00000;
        end else begin
            c1_reg <= next_c1;
            c2_reg <= next_c2;
            c3_reg <= next_c3;
        end
    end
    assign C1 = c1_reg;
    assign C2 = c2_reg;
    assign C3 = c3_reg;
    wire [7:0] led_result = mode_q2 ? q2_result : q1_result;
    wire [1:16] led_on;
    genvar i;
    generate for (i=1; i<=8; i=i+1) begin: led_bits
        assign led_on[i] = led_result[i-1];
    end endgenerate
    assign led_on[9] = mode_q2 ? q2_carry : q1_carry;
    assign led_on[10] = mode_q2 ? q2_zero : 1'b0;
    assign led_on[11:14] = 4'b0;
    assign led_on[15] = mode_q2 && q2_busy; // Optional pending-command indicator.
    assign led_on[16] = mode_q2 ? q2_error : q1_error;
    assign LED = LED_ACTIVE_LOW ? ~led_on : led_on;
endmodule
