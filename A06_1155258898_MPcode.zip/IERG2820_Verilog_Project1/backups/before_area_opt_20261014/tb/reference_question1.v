// Unmodified baseline, simulation only.
`timescale 1ns/1ps
// Question 1: unsigned 4-bit calculator with repeated '='.
// Default follows the specified 4-bit ADD/SUB result + separate carry/borrow.
// On repeated '=', the low nibble of the previous result is the new Group-A.
// CHAIN_8BIT=1 optionally keeps all 8 bits for repeated operations ONLY.
module reference_question1 #(
    parameter CHAIN_8BIT = 0
) (
    input wire clk,
    input wire reset,
    input wire enable,
    input wire execute,
    input wire [3:0] group_a,
    input wire [3:0] group_b,
    input wire [1:0] operator_code,
    output reg [7:0] result,
    output reg carry_borrow,
    output reg error,
    output reg show_result
);
    reg [3:0] saved_a, saved_b;
    reg [1:0] saved_op;
    wire same_inputs = (group_a == saved_a) && (group_b == saved_b) &&
                       (operator_code == saved_op);
    wire repeat_op = show_result && same_inputs;
    wire wide_op = CHAIN_8BIT && repeat_op;
    wire [7:0] lhs = repeat_op ? (wide_op ? result : {4'b0, result[3:0]})
                                      : {4'b0, group_a};
    wire [7:0] rhs = {4'b0, group_b};
    reg [7:0] next_result;
    reg next_carry, next_error;
    reg [8:0] sum_diff;
    reg [15:0] product;
    always @* begin
        next_result = result;
        next_carry = 0;
        next_error = 0;
        sum_diff = 0;
        product = 0;
        case (operator_code)
            2'b00: begin
                sum_diff = {1'b0, lhs} + {1'b0, rhs};
                next_result = wide_op ? sum_diff[7:0] : {4'b0, sum_diff[3:0]};
                next_carry = wide_op ? sum_diff[8] : sum_diff[4];
            end
            2'b01: begin
                sum_diff = {1'b0, lhs} - {1'b0, rhs};
                next_result = wide_op ? sum_diff[7:0] : {4'b0, sum_diff[3:0]};
                next_carry = (lhs < rhs);
            end
            2'b10: begin
                product = lhs * rhs;
                next_result = product[7:0];
                next_carry = wide_op && (product[15:8] != 0);
            end
            2'b11: begin
                if (rhs == 0) next_error = 1;
                else next_result = lhs / rhs; // Unsigned integer quotient.
            end
        endcase
    end
    always @(posedge clk) begin
        if (reset) begin
            result <= 0;
            carry_borrow <= 0;
            error <= 0;
            show_result <= 0;
            saved_a <= 0;
            saved_b <= 0;
            saved_op <= 0;
        end else if (enable) begin
            if (!same_inputs) begin
                show_result <= 0;
                saved_a <= group_a;
                saved_b <= group_b;
                saved_op <= operator_code;
            end
            if (execute) begin
                result <= next_result;
                carry_borrow <= next_carry;
                error <= next_error;
                show_result <= 1;
                saved_a <= group_a;
                saved_b <= group_b;
                saved_op <= operator_code;
            end
        end
    end
endmodule
