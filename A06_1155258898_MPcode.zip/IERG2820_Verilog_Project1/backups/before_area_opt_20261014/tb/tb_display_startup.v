`timescale 1ns/1ps
module tb_display_startup;
 reg clk=0, clock_run=1;
 always #10 if(clock_run) clk=~clk;
 reg [1:12] t=0; reg [1:4] k=4'b000z;
 wire [1:16] led; wire [7:0] c1,c2; wire [16:0] c3; wire cc;
 mini_project_top #(.DEBOUNCE_CYCLES(3)) dut(clk,t,k,1'b0,1'b0,led,c1,c2,c3,cc);
 task ticks; input integer n; begin repeat(n) begin @(posedge clk); #1; end end endtask
 initial begin
  ticks(12);
  if(c1!==8'h3f || c2!==8'h3f || c3!==17'h04b00) $fatal(1,"Q1 power-up must show 0,0,+");
  @(negedge clk); k[4]=1; ticks(8);
  if(c1!==8'h3f || c2!==8'h3f || c3!==17'h04b00 || dut.reset!==0) $fatal(1,"High K4 must not blank displays");
  @(negedge clk); k[4]=1'bx; ticks(8);
  if(c1!==8'h3f || c2!==8'h3f || c3!==17'h04b00 || dut.reset!==0) $fatal(1,"Unknown K4 must be ignored");
  @(negedge clk); clock_run=0; k[4]=0; #200;
  if(c1!==8'h3f || c2!==8'h3f || c3!==17'h04b00) $fatal(1,"Stopped clock must retain displayed state");
  clock_run=1; ticks(12);
  if(c1!==8'h3f || c2!==8'h3f || c3!==17'h04b00) $fatal(1,"Clock and reset recovery");
  $display("PASS current defaults: power-up 0/0/+ with floating K4; high/unknown K4 ignored; stopped clock retains state"); $finish;
 end
endmodule
