`timescale 1ns/1ps
module tb_question1;
    reg clk=0, reset=1, enable=1, execute=0;
    always #10 clk=~clk;
    reg [3:0] a=0,b=0;
    reg [1:0] op=0;
    wire [7:0] result, wide_result;
    wire carry,error,show_result,wide_carry;
    integer x,y,k,expected,expected_carry,expected_error,tests=0;
    question1 dut (.clk(clk),.reset(reset),.enable(enable),.execute(execute),
        .group_a(a),.group_b(b),.operator_code(op),.result(result),
        .carry_borrow(carry),.error(error),.show_result(show_result),
        .math_product(16'b0),.math_quotient(8'b0),.math_lhs());
    question1 #(.CHAIN_8BIT(1)) wide_dut
        (.clk(clk),.reset(reset),.enable(enable),.execute(execute),
         .group_a(a),.group_b(b),.operator_code(op),.result(wide_result),
         .carry_borrow(wide_carry),.error(),.show_result(),
         .math_product(16'b0),.math_quotient(8'b0),.math_lhs());
    task tick; begin @(posedge clk); #1; end endtask
    task check;
        input [7:0] r;
        input c,e;
        begin
            tests=tests+1;
            if (result !== r || carry !== c || error !== e)
                $fatal(1,"Q1 a=%0d b=%0d op=%0d got=%0d C=%b E=%b expected=%0d C=%b E=%b",
                    a,b,op,result,carry,error,r,c,e);
        end
    endtask
    task press;
        begin @(negedge clk); execute=1; tick; @(negedge clk); execute=0; end
    endtask
    initial begin
        for (k=0;k<4;k=k+1) for (x=0;x<16;x=x+1) for (y=0;y<16;y=y+1) begin
            @(negedge clk); reset=1; execute=0; tick;
            @(negedge clk); reset=0; a=x; b=y; op=k;
            tick;
            if(show_result !== 0) $fatal(1,"Q1 preview expected");
            expected_carry=0; expected_error=0;
            case(k)
                0: begin expected=(x+y)%16; expected_carry=(x+y)>15; end
                1: begin expected=(x-y+16)%16; expected_carry=x<y; end
                2: expected=x*y;
                3: begin expected=(y==0)?0:x/y; expected_error=(y==0); end
            endcase
            press; check(expected,expected_carry,expected_error);
        end
        @(negedge clk); a=1; b=2; op=0; tick;
        press; check(3,0,0);
        press; check(5,0,0);
        press; check(7,0,0);
        @(negedge clk); enable=0; execute=1; tick; check(7,0,0);
        @(negedge clk); enable=1; execute=0; b=3; tick;
        if(show_result !== 0) $fatal(1,"Q1 changed input must restore preview");
        press; check(4,0,0);
        @(negedge clk); a=15; b=15; op=2; tick;
        press; check(225,0,0);
        press; check(15,0,0);
        if(wide_result !== 47 || wide_carry !== 1) $fatal(1,"Q1 optional 8-bit chain");
        @(negedge clk); b=0; op=3; tick;
        press; check(15,0,1); // Failed division preserves last valid result.
        $display("PASS Q1: %0d result/status checks, all 1024 4-bit input cases",tests);
        $finish;
    end
endmodule
