`timescale 1ns/1ps
module tb_core_equivalence;
    reg clk=0,reset=1,enable=1,execute=0,step=0;
    reg [3:0] a=0,b=0,opcode=0;
    reg [1:0] op=0;
    reg [7:0] data=0;
    wire [10:0] q1_old[0:1],q1_new[0:1];
    wire [43:0] q2_old,q2_new;
    integer i,seed=28202026;
    always #10 clk=~clk;
    genvar g;
    generate for(g=0;g<2;g=g+1) begin: q1_modes
        reference_question1 #(.CHAIN_8BIT(g)) old_q1
            (clk,reset,enable,execute,a,b,op,
             q1_old[g][10:3],q1_old[g][2],q1_old[g][1],q1_old[g][0]);
        question1 #(.CHAIN_8BIT(g)) new_q1
            (clk,reset,enable,execute,a,b,op,
             q1_new[g][10:3],q1_new[g][2],q1_new[g][1],q1_new[g][0],16'b0,8'b0,);
        always @(posedge clk) begin
            #2;
            if(q1_new[g]!==q1_old[g])
                $fatal(1,"Q1 equivalence mismatch chain=%0d at %0t",g,$time);
        end
    end endgenerate
    reference_question2 old_q2(clk,reset,enable,step,execute,data,opcode,
        q2_old[43:36],q2_old[35:28],q2_old[27:20],q2_old[19:12],
        q2_old[11],q2_old[10],q2_old[9],q2_old[8:1],q2_old[0]);
    question2 new_q2(clk,reset,enable,step,execute,data,opcode,
        q2_new[43:36],q2_new[35:28],q2_new[27:20],q2_new[19:12],
        q2_new[11],q2_new[10],q2_new[9],q2_new[8:1],q2_new[0],16'b0,8'b0);
    always @(posedge clk) begin
        #2;
        if(q2_new!==q2_old)
            $fatal(1,"Q2 equivalence mismatch at %0t: old=%h new=%h",$time,q2_old,q2_new);
    end
    initial begin
        repeat(3) @(negedge clk);
        reset=0;
        for(i=0;i<100000;i=i+1) begin
            @(negedge clk);
            reset=(i%2003==0);
            if(i%251==0) enable=~enable;
            execute=($random(seed)&3)==0;
            step=(i%10==0);
            data=$random(seed);
            opcode=$random(seed);
            if(i%19==0) begin a=$random(seed);b=$random(seed);op=$random(seed);end
        end
        @(negedge clk);
        $display("PASS core equivalence: 100000 cycles, both Q1 widths and all Q2 architectural outputs match baseline");
        $finish;
    end
endmodule
