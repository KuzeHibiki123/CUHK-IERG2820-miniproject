`timescale 1ns/1ps
module filter_comparison #(parameter WIDTH=1, parameter N=3) (
    input wire clk, reset,
    input wire [WIDTH-1:0] raw
);
    wire [WIDTH-1:0] new_level,new_rise,old_level,old_rise;
    input_filter #(.WIDTH(WIDTH),.STABLE_CYCLES(N)) optimized
        (clk,reset,raw,new_level,new_rise);
    reference_input_filter #(.WIDTH(WIDTH),.STABLE_CYCLES(N)) baseline
        (clk,reset,raw,old_level,old_rise);
    always @(posedge clk) begin
        #1;
        if(new_level!==old_level || new_rise!==old_rise)
            $fatal(1,"Filter mismatch WIDTH=%0d N=%0d at %0t: new=%h/%h old=%h/%h",
                   WIDTH,N,$time,new_level,new_rise,old_level,old_rise);
    end
endmodule

module tb_filter_equivalence;
    reg clk=0,reset=1;
    reg [11:0] raw=0;
    integer i,seed=20261012;
    always #10 clk=~clk;
    genvar n;
    generate for(n=1;n<=8;n=n+1) begin: comparisons
        filter_comparison #(.WIDTH(1),.N(n)) one_bit(clk,reset,raw[0]);
        filter_comparison #(.WIDTH(12),.N(n)) bus_bits(clk,reset,raw);
    end endgenerate
    filter_comparison #(.WIDTH(1),.N(31)) long_bit(clk,reset,raw[0]);
    filter_comparison #(.WIDTH(12),.N(31)) long_bus(clk,reset,raw);
    initial begin
        repeat(3) @(negedge clk);
        reset=0;
        for(i=0;i<20000;i=i+1) begin
            @(negedge clk);
            // Short bounce bursts followed by increasingly long stable gaps.
            if(i%101 < 20 || i%101 == 30 || i%101 == 60) raw=$random(seed);
            reset=(i%997==0);
        end
        reset=0;
        repeat(40) @(negedge clk);
        $display("PASS filter equivalence: 18 configurations, 20000 stimulus cycles, identical level/rise every cycle");
        $finish;
    end
endmodule
