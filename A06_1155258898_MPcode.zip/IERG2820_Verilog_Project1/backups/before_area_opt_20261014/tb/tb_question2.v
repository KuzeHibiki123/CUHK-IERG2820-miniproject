`timescale 1ns/1ps
module tb_question2;
    reg clk=0,reset=1,enable=1,step_ce=0,execute=0;
    always #10 clk=~clk;
    reg [7:0] data=0;
    reg [3:0] op=0;
    wire [7:0] a,b,c,result,display_value;
    wire carry,zero,error,busy;
    integer x,y,tests=0,p;
    question2 dut (.clk(clk),.reset(reset),.enable(enable),.step_ce(step_ce),
        .execute(execute),.data_in(data),.opcode(op),.reg_a(a),.reg_b(b),.reg_c(c),
        .result(result),.carry_borrow(carry),.zero(zero),.error(error),
        .display_value(display_value),.busy(busy),
        .math_product(16'b0),.math_quotient(8'b0));
    task tick; begin @(posedge clk); #1; end endtask
    task issue;
        input [3:0] instruction;
        input [7:0] value;
        begin
            @(negedge clk); op=instruction; data=value; step_ce=1; execute=1;
            tick;
            @(negedge clk); execute=0; step_ce=0;
        end
    endtask
    task check;
        input [7:0] expected_a,expected_b,expected_c,expected_result;
        input expected_carry,expected_error;
        begin
            tests=tests+1;
            if(a !== expected_a || b !== expected_b || c !== expected_c ||
               result !== expected_result || carry !== expected_carry ||
               error !== expected_error || zero !== (expected_result==0))
                $fatal(1,"Q2 op=%h x=%0d y=%0d A/B/C/R=%h/%h/%h/%h CZE=%b%b%b expected=%h/%h/%h/%h C/E=%b/%b",
                    op,x,y,a,b,c,result,carry,zero,error,
                    expected_a,expected_b,expected_c,expected_result,expected_carry,expected_error);
        end
    endtask
    initial begin
        tick; @(negedge clk); reset=0;
        // Capture a request, then change live inputs before the commit edge.
        @(negedge clk); execute=1; op=0; data=8'hA5; tick;
        if(!busy || a!==0) $fatal(1,"Q2 queue must not execute early");
        @(negedge clk); execute=0; data=8'h5A; op=1;
        repeat(5) begin tick; if(a!==0 || b!==0) $fatal(1,"Q2 changed without step_ce"); end
        @(negedge clk); step_ce=1; tick; check(8'hA5,0,0,8'hA5,0,0);
        if(busy) $fatal(1,"Q2 pending not cleared");
        @(negedge clk); step_ce=0; execute=1; op=1; data=7; tick;
        @(negedge clk); execute=0; tick;
        // Commit queued LOAD B and refill with LOAD C on the same edge.
        @(negedge clk); step_ce=1; execute=1; op=2; data=9; tick;
        check(8'hA5,7,0,7,0,0);
        if(!busy) $fatal(1,"Q2 refill failed");
        @(negedge clk); execute=0; tick; check(8'hA5,7,9,9,0,0);
        @(negedge clk); step_ce=0;
        // A mode change cancels a queued command, retaining registers.
        @(negedge clk); execute=1; op=0; data=0; tick;
        @(negedge clk); execute=0; enable=0; tick;
        @(negedge clk); enable=1; step_ce=1; tick; check(8'hA5,7,9,9,0,0);
        @(negedge clk); step_ce=0;
        // All pairs for ADD B/C, SUB B/C, MUL B, DIV B.
        for(x=0;x<256;x=x+1) for(y=0;y<256;y=y+1) begin
            issue(1,y); issue(2,y);
            issue(0,x); issue(4,0); check((x+y)%256,y,y,(x+y)%256,(x+y)>255,0);
            issue(0,x); issue(5,0); check((x+y)%256,y,y,(x+y)%256,(x+y)>255,0);
            issue(0,x); issue(6,0); check((x-y+256)%256,y,y,(x-y+256)%256,x<y,0);
            issue(0,x); issue(7,0); check((x-y+256)%256,y,y,(x-y+256)%256,x<y,0);
            issue(0,x); issue(8,0); p=x*y; check(p%256,p/256,y,p%256,p>255,0);
            issue(1,y); issue(0,x); issue(9,0);
            if(y==0) check(x,0,y,x,0,1);
            else check(x/y,y,y,x/y,0,0);
        end
        for(x=0;x<256;x=x+1) begin
            issue(0,x); issue(3,0); check(255-x,255,255,255-x,0,0);
            issue(0,x); issue(10,0); check((x*2)%256,255,255,(x*2)%256,x>=128,0);
            issue(0,x); issue(11,0); check(x/2,255,255,x/2,x%2,0);
        end
        issue(0,12); issue(1,34); issue(2,56);
        if(display_value!==12) $fatal(1,"Default display must be A");
        issue(13,0); if(display_value!==34 || result!==34) $fatal(1,"OUT B");
        issue(14,0); if(display_value!==56 || result!==56) $fatal(1,"OUT C");
        issue(12,0); if(display_value!==12 || result!==12) $fatal(1,"OUT A");
        issue(1,0); issue(9,0); check(12,0,56,12,0,1);
        issue(15,255); check(12,0,56,12,0,1);
        issue(14,0); check(12,0,56,56,0,1); // OUT keeps the error flag.
        issue(0,0); check(0,0,56,0,0,0);
        $display("PASS Q2: %0d register/result/status checks; all operand pairs for 6 arithmetic opcodes",tests);
        $finish;
    end
endmodule
