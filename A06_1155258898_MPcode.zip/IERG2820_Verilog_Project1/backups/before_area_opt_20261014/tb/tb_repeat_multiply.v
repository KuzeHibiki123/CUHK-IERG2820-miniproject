`timescale 1ns/1ps
module tb_repeat_multiply;
 reg clk=0; always #10 clk=~clk;
 reg [1:12] t=0; reg [1:4] k=0; reg sw1=0,sw2=0;
 wire [1:16] led[0:3]; wire [7:0] c1[0:3],c2[0:3]; wire [16:0] c3[0:3];
 wire cc[0:3]; wire [7:0] qa[0:3],qb[0:3],q1result[0:3];
 genvar g;
 generate for(g=0;g<4;g=g+1) begin: modes
  mini_project_top #(.CLOCK_HZ(200),.CPU_HZ(10),.DEBOUNCE_CYCLES(3),
   .Q1_CHAIN_8BIT(g%2),.SHARE_MATH(g/2)) dut
   (clk,t,k,sw1,sw2,led[g],c1[g],c2[g],c3[g],cc[g]);
  assign qa[g]=dut.q2_a; assign qb[g]=dut.q2_b; assign q1result[g]=dut.q1_result;
 end endgenerate
 integer i,j,wanted,strict_wanted;
 reg [7:0] seven[0:9]; reg [16:0] star[0:9];
 task ticks; input integer n; begin repeat(n) begin @(posedge clk); #1; end end endtask
 task data; input [7:0] v; integer n; begin for(n=0;n<8;n=n+1)t[n+1]=v[n];end endtask
 task opcode; input [3:0] v; begin t[9]=v[3];t[10]=v[2];t[11]=v[1];t[12]=v[0];end endtask
 task press;begin @(negedge clk);sw1=1;ticks(10);@(negedge clk);sw1=0;ticks(35);end endtask
 task issue;input [3:0] op;input [7:0] v;begin @(negedge clk);opcode(op);data(v);ticks(15);press;end endtask
 task check_outputs;
 input integer m,v,carry;
 integer n;
 reg [7:0] binary;
 begin
  for(n=0;n<8;n=n+1)binary[n]=led[m][n+1];
  if(binary!==v || led[m][9]!==carry[0])$fatal(1,"LED/result mode=%0d value=%0d actual=%0d carry=%b",m,v,binary,led[m][9]);
  if(c1[m] !== ((v<100)?8'b0:seven[v/100]) ||
     c3[m] !== ((v<10)?17'b0:star[(v/10)%10]) || c2[m]!==seven[v%10])
    $fatal(1,"Decimal layout mode=%0d value=%0d C1/C3/C2=%h/%h/%h",m,v,c1[m],c3[m],c2[m]);
 end endtask
 initial begin
  seven[0]='h3f;seven[1]='h06;seven[2]='h5b;seven[3]='h4f;seven[4]='h66;
  seven[5]='h6d;seven[6]='h7d;seven[7]='h07;seven[8]='h7f;seven[9]='h6f;
  star[0]='h0ff;star[1]='h00c;star[2]='h377;star[3]='h33f;star[4]='h38c;
  star[5]='h3bb;star[6]='h3fb;star[7]='h00f;star[8]='h3ff;star[9]='h3bf;
  ticks(15);@(negedge clk);data(8'h22);opcode(8);ticks(15);
  for(i=0;i<7;i=i+1)begin
   press;wanted=(4<<i)%256;strict_wanted=(i<3)?wanted:0;
   for(j=0;j<4;j=j+1)begin
    if(q1result[j]!==((j%2)?wanted:strict_wanted))$fatal(1,"Q1 chain mode=%0d step=%0d",j,i);
    check_outputs(j,(j%2)?wanted:strict_wanted,(j%2)&&(i==6));
   end
   $display("Q1 step %0d: CHAIN_8BIT=0 -> %0d, CHAIN_8BIT=1 -> %0d, overflow=%0d",i+1,strict_wanted,wanted,i==6);
  end
  // Reproduce the reported 32 -> 0 with lab low-nibble chaining and the optional full-byte comparison.
  @(negedge clk);data(8'h48);opcode(8);ticks(15);press;
  for(j=0;j<4;j=j+1)if(q1result[j]!==32)$fatal(1,"Q1 8*4 initial result");
  press;
  for(j=0;j<4;j=j+1)begin
   if(q1result[j]!==((j%2)?128:0))$fatal(1,"Q1 reported 32 boundary");
   check_outputs(j,(j%2)?128:0,0);
  end
  $display("PASS reported Q1 case: 8*4=32, next equals lab default=0 / optional full-byte=128");
  @(negedge clk);sw2=1;ticks(15);issue(0,16);issue(1,2);issue(8,0);
  for(j=0;j<4;j=j+1)if(qa[j]!==32||qb[j]!==0)$fatal(1,"Q2 first MUL must store high byte into B");
  issue(8,0);
  for(j=0;j<4;j=j+1)if(qa[j]!==0||qb[j]!==0)$fatal(1,"Q2 repeated MUL uses overwritten B");
  $display("Q2 without LOAD B between MUL: A=32/B=0, then A=0/B=0 (specified register behavior)");
  issue(0,2);
  for(i=0;i<7;i=i+1)begin
   issue(1,2);issue(8,0);wanted=(4<<i)%256;
   for(j=0;j<4;j=j+1)begin
    if(qa[j]!==wanted || qb[j]!==((i==6)?1:0))$fatal(1,"Q2 reloaded multiply step=%0d mode=%0d",i,j);
    check_outputs(j,wanted,i==6);
   end
   $display("Q2 with B reloaded to 2: A=%0d, B(high product)=%0d",wanted,(i==6)?1:0);
  end
  $display("PASS repeated multiply: both chaining widths, shared/local math, LED flags, full decimal segments, Q2 high-byte storage");
  $finish;
 end
 initial begin #1000000;$fatal(1,"Timeout");end
endmodule
