// Unmodified baseline, simulation only.
`timescale 1ns/1ps
// Question 2: three 8-bit registers, all 16 instruction codes.
// SW1's one-clock pulse queues an instruction and its data. Commit on step_ce.
// One pending slot: while busy, further pulses are ignored, except on a commit
// edge where the old instruction commits and the new pulse refills the slot.
module reference_question2 (
    input wire clk,
    input wire reset,
    input wire enable,
    input wire step_ce,
    input wire execute,
    input wire [7:0] data_in,
    input wire [3:0] opcode,
    output reg [7:0] reg_a,
    output reg [7:0] reg_b,
    output reg [7:0] reg_c,
    output reg [7:0] result,
    output reg carry_borrow,
    output reg zero,
    output reg error,
    output wire [7:0] display_value,
    output reg busy
);
    reg [1:0] display_select;
    reg [7:0] pending_data;
    reg [3:0] pending_op;
    wire commit = enable && step_ce && (busy || execute);
    wire [3:0] current_op = busy ? pending_op : opcode;
    wire [7:0] current_data = busy ? pending_data : data_in;
    reg [7:0] new_a, new_b, new_c, new_result;
    reg new_carry, new_error;
    reg [1:0] new_select;
    reg [7:0] operand;
    reg [8:0] sum_diff;
    reg [15:0] product;
    assign display_value = (display_select == 1) ? reg_b :
                           (display_select == 2) ? reg_c : reg_a;
    always @* begin
        new_a = reg_a;
        new_b = reg_b;
        new_c = reg_c;
        new_result = result;
        new_select = display_select;
        new_carry = carry_borrow;
        new_error = error;
        operand = current_op[0] ? reg_c : reg_b;
        sum_diff = 0;
        product = 0;
        // LOAD and arithmetic clear stale status. OUT and NOP preserve C/E.
        if (current_op < 4'hC) begin
            new_carry = 0;
            new_error = 0;
        end
        case (current_op)
            4'h0: begin new_a = current_data; new_result = current_data; end
            4'h1: begin new_b = current_data; new_result = current_data; end
            4'h2: begin new_c = current_data; new_result = current_data; end
            4'h3: begin new_a = ~reg_a; new_result = new_a; end
            4'h4, 4'h5: begin
                sum_diff = {1'b0, reg_a} + {1'b0, operand};
                new_a = sum_diff[7:0];
                new_result = new_a;
                new_carry = sum_diff[8];
            end
            4'h6, 4'h7: begin
                sum_diff = {1'b0, reg_a} - {1'b0, operand};
                new_a = sum_diff[7:0];
                new_result = new_a;
                new_carry = (reg_a < operand);
            end
            4'h8: begin
                product = reg_a * reg_b;
                new_a = product[7:0];
                new_b = product[15:8];
                new_result = new_a;
                new_carry = (product[15:8] != 0);
            end
            4'h9: begin
                if (reg_b == 0) new_error = 1;
                else new_a = reg_a / reg_b;
                new_result = new_a;
            end
            4'hA: begin
                new_a = {reg_a[6:0], 1'b0}; // Logical shift, not rotate.
                new_result = new_a;
                new_carry = reg_a[7];
            end
            4'hB: begin
                new_a = {1'b0, reg_a[7:1]};
                new_result = new_a;
                new_carry = reg_a[0];
            end
            4'hC: begin new_select = 0; new_result = reg_a; end
            4'hD: begin new_select = 1; new_result = reg_b; end
            4'hE: begin new_select = 2; new_result = reg_c; end
            default: begin end // 1111 NOP: preserve all architectural state.
        endcase
    end
    always @(posedge clk) begin
        if (reset) begin
            reg_a <= 0;
            reg_b <= 0;
            reg_c <= 0;
            result <= 0;
            carry_borrow <= 0;
            zero <= 1;
            error <= 0;
            display_select <= 0;
            busy <= 0;
            pending_data <= 0;
            pending_op <= 0;
        end else begin
            if (!enable) busy <= 0;
            else if (commit) begin
                // Retain a newly arriving command if the old slot commits.
                busy <= busy && execute;
                if (busy && execute) begin
                    pending_data <= data_in;
                    pending_op <= opcode;
                end
            end else if (execute && !busy) begin
                busy <= 1;
                pending_data <= data_in;
                pending_op <= opcode;
            end
            if (commit) begin
                reg_a <= new_a;
                reg_b <= new_b;
                reg_c <= new_c;
                result <= new_result;
                carry_borrow <= new_carry;
                error <= new_error;
                display_select <= new_select;
                if (current_op != 4'hF) zero <= (new_result == 0);
            end
        end
    end
endmodule
