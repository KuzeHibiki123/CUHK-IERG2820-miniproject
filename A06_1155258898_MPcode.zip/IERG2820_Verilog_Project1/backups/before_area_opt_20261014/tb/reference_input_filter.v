// Baseline used only for cycle-by-cycle equivalence tests.
`timescale 1ns/1ps
// Synchronize asynchronous inputs, then accept a stable value after N clocks.
// A bus is qualified as a whole. Keep switches stable before pressing execute.
module reference_input_filter #(
    parameter WIDTH = 1,
    parameter STABLE_CYCLES = 500000
) (
    input wire clk,
    input wire reset,
    input wire [WIDTH-1:0] async_in,
    output reg [WIDTH-1:0] level,
    output reg [WIDTH-1:0] rise
);
    localparam COUNT_WIDTH = (STABLE_CYCLES < 2) ? 1 : $clog2(STABLE_CYCLES);
    (* altera_attribute = "-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS" *)
    reg [WIDTH-1:0] sync1, sync2;
    reg [WIDTH-1:0] candidate;
    reg [COUNT_WIDTH-1:0] count;
    always @(posedge clk) begin
        if (reset) begin
            sync1 <= 0;
            sync2 <= 0;
            candidate <= 0;
            count <= 0;
            level <= 0;
            rise <= 0;
        end else begin
            sync1 <= async_in;
            sync2 <= sync1;
            rise <= 0;
            if (sync2 == level) begin
                candidate <= sync2;
                count <= 0;
            end else if (STABLE_CYCLES <= 1) begin
                level <= sync2;
                rise <= sync2 & ~level;
                count <= 0;
            end else if (sync2 != candidate) begin
                candidate <= sync2;
                count <= 1;
            end else if (count == STABLE_CYCLES - 1) begin
                level <= sync2;
                rise <= sync2 & ~level;
                count <= 0;
            end else begin
                count <= count + 1'b1;
            end
        end
    end
endmodule
