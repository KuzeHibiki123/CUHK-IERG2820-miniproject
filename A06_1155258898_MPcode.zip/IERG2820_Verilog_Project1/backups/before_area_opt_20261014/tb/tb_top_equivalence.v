`timescale 1ns/1ps
module tb_top_equivalence;
    reg clk=0;
    reg [1:12] t=0;
    reg [1:4] k=0;
    reg sw1=0,sw2=0;
    integer i,seed=20262820,j;
    always #10 clk=~clk;
    genvar g;
    generate for(g=0;g<2;g=g+1) begin: checks
        wire [49:0] old_outputs,new_outputs;
        integer hits_q2[0:15];
        integer hits_q1[0:3];
        integer n;
        initial begin
            for(n=0;n<16;n=n+1) hits_q2[n]=0;
            for(n=0;n<4;n=n+1) hits_q1[n]=0;
        end
        reference_mini_project_top #(.CLOCK_HZ(200),.CPU_HZ(10),
            .DEBOUNCE_CYCLES(2),.Q1_CHAIN_8BIT(g),
            .C1_ACTIVE_LOW(0),.C2_ACTIVE_LOW(0),.C3_ACTIVE_LOW(0)) baseline
            (clk,t,k,sw1,sw2,old_outputs[49:34],old_outputs[33:26],
             old_outputs[25:18],old_outputs[17:1],old_outputs[0]);
        mini_project_top #(.CLOCK_HZ(200),.CPU_HZ(10),
            .DEBOUNCE_CYCLES(2),.Q1_CHAIN_8BIT(g),
            .C1_ACTIVE_LOW(0),.C2_ACTIVE_LOW(0),.C3_ACTIVE_LOW(0)) optimized
            (clk,t,k,sw1,sw2,new_outputs[49:34],new_outputs[33:26],
             new_outputs[25:18],new_outputs[17:1],new_outputs[0]);
        always @(posedge clk) begin
            if(!baseline.reset) begin
                if(baseline.q2.commit) hits_q2[baseline.q2.current_op]=hits_q2[baseline.q2.current_op]+1;
                if(!baseline.mode_q2 && baseline.execute_pulse)
                    hits_q1[baseline.q1_operator]=hits_q1[baseline.q1_operator]+1;
            end
            #2;
            if(new_outputs!==old_outputs)
                $fatal(1,"Top equivalence CHAIN_8BIT=%0d failed at %0t: old=%h new=%h",g,$time,old_outputs,new_outputs);
        end
    end endgenerate
    initial begin
        k[4]=1;
        repeat(4) @(negedge clk);
        k[4]=0;
        for(i=0;i<100000;i=i+1) begin
            @(negedge clk);
            if(i%40==0) t=$random(seed);
            sw1=(i%16>=8);
            sw2=(i%1600>=800);
            k[1]=(i%201>=100);
            k[4]=(i%2501==0);
        end
        @(negedge clk);
        for(j=0;j<16;j=j+1) begin
            if(checks[0].hits_q2[j]==0 || checks[1].hits_q2[j]==0)
                $fatal(1,"Q2 opcode %0d not covered",j);
        end
        for(j=0;j<4;j=j+1) begin
            if(checks[0].hits_q1[j]==0 || checks[1].hits_q1[j]==0)
                $fatal(1,"Q1 opcode %0d not covered",j);
        end
        $display("PASS top equivalence: 100000 cycles, both Q1 widths, all Q1/Q2 opcodes, every LED/segment/CCLK output matches baseline");
        $finish;
    end
endmodule
