`timescale 1ns/1ps
// OPD-AS5010 (common anode) / AS5011 (common cathode), 16 segments + DP.
// seg[16:0] = {DP,N,M,L,K,J,H,G2,G1,F,E,D2,D1,C,B,A2,A1}.
module c3_display #(
    parameter ACTIVE_LOW = 1
) (
    input wire [3:0] digit,
    input wire blank,
    input wire decimal_point,
    input wire operator_mode,
    input wire [1:0] operator_code, // {T9,T10}: +, -, x, /
    output wire [16:0] seg
);
    wire [6:0] decoded;
    reg [16:0] lit;
    hex7_decoder decoder (.digit(digit), .seg_on(decoded));
    always @* begin
        lit = 17'b0;
        if (!blank) begin
            if (operator_mode) begin
                case (operator_code)
                    2'b00: lit = 17'h04B00; // G1,G2,J,M: +
                    2'b01: lit = 17'h00300; // G1,G2: -
                    2'b10: lit = 17'h0B400; // H,K,L,N: x
                    2'b11: lit = 17'h09000; // K,N: / (division)
                endcase
            end else begin
                lit[1:0] = {2{decoded[0]}}; // A -> A1,A2
                lit[2] = decoded[1];       // B
                lit[3] = decoded[2];       // C
                lit[5:4] = {2{decoded[3]}}; // D -> D1,D2
                lit[6] = decoded[4];       // E
                lit[7] = decoded[5];       // F
                lit[9:8] = {2{decoded[6]}}; // G -> G1,G2
            end
            lit[16] = decimal_point;
        end
    end
    assign seg = ACTIVE_LOW ? ~lit : lit;
endmodule
