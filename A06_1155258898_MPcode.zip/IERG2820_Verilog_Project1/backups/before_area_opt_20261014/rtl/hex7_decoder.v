`timescale 1ns/1ps
// Active-high seven-segment truth table. seg_on[6:0] = {G,F,E,D,C,B,A}.
module hex7_decoder (
    input wire [3:0] digit,
    output reg [6:0] seg_on
);
    always @* begin
        case (digit)
            4'h0: seg_on = 7'b0111111;
            4'h1: seg_on = 7'b0000110;
            4'h2: seg_on = 7'b1011011;
            4'h3: seg_on = 7'b1001111;
            4'h4: seg_on = 7'b1100110;
            4'h5: seg_on = 7'b1101101;
            4'h6: seg_on = 7'b1111101;
            4'h7: seg_on = 7'b0000111;
            4'h8: seg_on = 7'b1111111;
            4'h9: seg_on = 7'b1101111;
            4'hA: seg_on = 7'b1110111;
            4'hB: seg_on = 7'b1111100; // b
            4'hC: seg_on = 7'b0111001;
            4'hD: seg_on = 7'b1011110; // d
            4'hE: seg_on = 7'b1111001;
            4'hF: seg_on = 7'b1110001;
            default: seg_on = 7'b0000000;
        endcase
    end
endmodule
