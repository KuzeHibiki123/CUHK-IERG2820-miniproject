`timescale 1ns/1ps
// All logic uses clk. step_ce is sampled on the very edge that raises CCLK.
// CCLK is an oscilloscope output; it is NOT used as an internal clock.
module clock_enable #(
    parameter CLOCK_HZ = 50000000,
    parameter STEP_HZ = 1
) (
    input wire clk,
    input wire reset,
    output reg cclk,
    output wire step_ce
);
    localparam HALF_PERIOD = CLOCK_HZ / (2 * STEP_HZ);
    localparam COUNT_WIDTH = (HALF_PERIOD < 2) ? 1 : $clog2(HALF_PERIOD);
    reg [COUNT_WIDTH-1:0] count;
    assign step_ce = !reset && !cclk && (count == HALF_PERIOD - 1);
    always @(posedge clk) begin
        if (reset) begin
            count <= 0;
            cclk <= 0;
        end else if (count == HALF_PERIOD - 1) begin
            count <= 0;
            cclk <= ~cclk;
        end else begin
            count <= count + 1'b1;
        end
    end
endmodule

// Keep all internal registers on clk; only Q2's execution enable changes.
// CCLK is a scope output. Select on clk's falling edge, avoiding extra rising
// edges between input clock edges when changing rates.
module selectable_clock_enable #(
    parameter CLOCK_HZ = 50000000,
    parameter STEP_HZ = 1
) (
    input wire clk,
    input wire reset,
    input wire slow_mode,
    output wire cclk,
    output wire step_ce
);
    reg fast_selected = 1'b1;
    wire slow_cclk, slow_ce;
    always @(negedge clk) begin
        if (reset) fast_selected <= 1'b1;
        else fast_selected <= !slow_mode;
    end
    clock_enable #(.CLOCK_HZ(CLOCK_HZ), .STEP_HZ(STEP_HZ)) divider
        (.clk(clk), .reset(reset || fast_selected),
         .cclk(slow_cclk), .step_ce(slow_ce));
    assign cclk = fast_selected ? clk : slow_cclk;
    assign step_ce = !reset && (fast_selected || slow_ce);
endmodule
