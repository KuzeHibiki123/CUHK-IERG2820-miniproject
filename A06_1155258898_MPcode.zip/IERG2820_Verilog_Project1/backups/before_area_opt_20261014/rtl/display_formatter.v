`timescale 1ns/1ps
// Result layout: decimal physical C1/C3/C2 = hundreds/tens/ones (leading zeros blank).
// Hexadecimal C1/C2 = high/low nibble; C3 is blank.
module display_formatter (
    input wire [7:0] value,
    input wire hex_mode,
    output reg [3:0] digit_c1,
    output reg [3:0] digit_c2,
    output reg [3:0] digit_c3,
    output reg [2:0] blank // [0]=C1, [1]=C2, [2]=C3
);
    reg [11:0] bcd;
    integer i;
    always @* begin
        // Double-dabble conversion avoids a decimal divider.
        bcd = 12'b0;
        for (i = 7; i >= 0; i = i - 1) begin
            if (bcd[3:0] >= 5) bcd[3:0] = bcd[3:0] + 4'd3;
            if (bcd[7:4] >= 5) bcd[7:4] = bcd[7:4] + 4'd3;
            if (bcd[11:8] >= 5) bcd[11:8] = bcd[11:8] + 4'd3;
            bcd = {bcd[10:0], value[i]};
        end
        if (hex_mode) begin
            digit_c1 = value[7:4];
            digit_c2 = value[3:0];
            digit_c3 = 4'd0;
            blank = 3'b100;
        end else begin
            digit_c1 = bcd[11:8];
            digit_c2 = bcd[3:0];
            digit_c3 = bcd[7:4];
            blank[0] = (bcd[11:8] == 0);
            blank[1] = 1'b0;
            blank[2] = (bcd[11:4] == 0);
        end
    end
endmodule
