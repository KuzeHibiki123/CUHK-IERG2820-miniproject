`timescale 1ns/1ps
module tb_multiplication_bounds;
 reg clk=0; always #10 clk=~clk;
 reg [1:12] t=0; reg [1:4] k=0; reg sw1=0,sw2=0;
 wire [1:16] led; wire [7:0] c1,c2; wire [16:0] c3; wire cc;
 mini_project_top #(.CLOCK_HZ(200),.CPU_HZ(10),.DEBOUNCE_CYCLES(3)) dut(clk,t,k,sw1,sw2,led,c1,c2,c3,cc);
 integer i;
 task ticks; input integer n; begin repeat(n) begin @(posedge clk); #1; end end endtask
 task data; input [7:0] value; integer j; begin for(j=0;j<8;j=j+1) t[j+1]=value[j]; end endtask
 task opcode; input [3:0] value; begin t[9]=value[3];t[10]=value[2];t[11]=value[1];t[12]=value[0]; end endtask
 task press; begin @(negedge clk);sw1=1;ticks(10);@(negedge clk);sw1=0;ticks(35);end endtask
 task issue; input [3:0] op;input [7:0] value;begin @(negedge clk);opcode(op);data(value);ticks(15);press;end endtask
 function [7:0] led_value;input [1:16] bits;integer j;begin for(j=0;j<8;j=j+1)led_value[j]=bits[j+1];end endfunction
 initial begin
  ticks(15);
  @(negedge clk);data(255);opcode(8);ticks(15);press;
  if(dut.q1_result!==225 || led_value(led)!==8'hE1 || c1!==8'h5B || c3!==17'h377 || c2!==8'h6D)
   $fatal(1,"Q1 15*15 must preserve 8-bit E1 and display 225 (C1/C3/C2)");
  $display("PASS Q1 15*15 = 225 = 8'b11100001, displays C1/C3/C2 = 2/2/5");
  press;
  if(dut.q1_result!==15) $fatal(1,"Default repeated operation uses prior low nibble");
  $display("PASS Q1 repeated equals: default 4-bit operand policy makes the next result 15");
  @(negedge clk);sw2=1;ticks(15);
  issue(0,15);issue(1,17);issue(8,0);
  if(dut.q2_a!==255 || dut.q2_b!==0 || led_value(led)!==255 || c1!==8'h5B || c3!==17'h3BB || c2!==8'h6D)
   $fatal(1,"Q2 15*17 must produce 255 and display 2/5/5");
  $display("PASS Q2 15*17 = 255 = 8'b11111111, displays C1/C3/C2 = 2/5/5");
  issue(0,255);issue(1,255);issue(8,0);
  if(dut.q2_a!==1 || dut.q2_b!==254 || led_value(led)!==1 || led[9]!==1 || c1!==0 || c3!==0 || c2!==8'h06)
   $fatal(1,"Q2 255*255 must split FE01 into B=254/A=1");
  $display("PASS Q2 255*255 = 65025 = 16'hFE01, B=254/A=1, default display=1");
  issue(13,0);
  if(c1!==8'h5B || c3!==17'h3BB || c2!==8'h66 || led_value(led)!==254)
   $fatal(1,"OUT B must display 254");
  $display("PASS Q2 OUT B displays high byte 254");
  $finish;
 end
 initial begin #1000000;$fatal(1,"Timeout");end
endmodule
