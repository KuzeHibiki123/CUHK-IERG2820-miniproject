`timescale 1ns/1ps
module tb_display_rom;
 reg clk=0; always #5 clk=~clk;
 reg reset=1,hex_mode=0,preview=0;
 reg [7:0] value=0;
 reg [1:0] op=0;
 wire [3:0] rd1,rd2,rd3;
 wire [2:0] rb;
 display_formatter reference_formatter(value,hex_mode,rd1,rd2,rd3,rb);
 wire [3:0] d1=preview ? ((!hex_mode && value[3:0]>=10)?value[3:0]-4'd10:value[3:0]) : rd1;
 wire [3:0] d2=preview ? ((!hex_mode && value[7:4]>=10)?value[7:4]-4'd10:value[7:4]) : rd2;
 wire dp1=preview && !hex_mode && value[3:0]>=10;
 wire dp2=preview && !hex_mode && value[7:4]>=10;
 genvar g;
 generate for(g=0;g<2;g=g+1)begin: polarities
  wire [7:0] a,b,refa,refb;
  wire [16:0] c,refc;
  c1_registered_display #(.ACTIVE_LOW(g)) c1(clk,reset,value,hex_mode,preview,a);
  c2_registered_display #(.ACTIVE_LOW(g)) c2(clk,reset,value,hex_mode,preview,b);
  c3_registered_display #(.ACTIVE_LOW(g)) c3(clk,reset,value,hex_mode,preview,op,c);
  c1_display #(.ACTIVE_LOW(g)) old1(d1,preview?1'b0:rb[0],dp1,refa);
  c2_display #(.ACTIVE_LOW(g)) old2(d2,preview?1'b0:rb[1],dp2,refb);
  c3_display #(.ACTIVE_LOW(g)) old3(rd3,preview?1'b0:rb[2],1'b0,preview,op,refc);
  reg [7:0] wanta,wantb;
  reg [16:0] wantc;
  always @(posedge clk)begin
   wanta=reset?(g?8'hff:8'h00):refa;
   wantb=reset?(g?8'hff:8'h00):refb;
   wantc=reset?(g?17'h1ffff:17'h00000):refc;
   #1;
   if(a!==wanta || b!==wantb || c!==wantc)
    $fatal(1,"ROM differs: polarity=%0d preview=%b hex=%b value=%0d op=%0d reset=%b",g,preview,hex_mode,value,op,reset);
  end
 end endgenerate
 integer i;
 initial begin
  for(i=0;i<8192;i=i+1)begin
   @(negedge clk);{reset,preview,hex_mode,op,value}=i;
  end
  @(posedge clk);#2;
  $display("PASS display ROM: 8192 input combinations, both polarities, preview DP, all operators, decimal/hex, reset and exact one-cycle latency");
  $finish;
 end
endmodule
