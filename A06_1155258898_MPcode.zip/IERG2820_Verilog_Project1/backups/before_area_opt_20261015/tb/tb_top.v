`timescale 1ns/1ps
module tb_top;
    reg clk=0;
    always #10 clk=~clk;
    reg [1:12] t=0;
    reg [1:4] k=0;
    reg sw1=0,sw2=0;
    wire [1:16] led;
    wire [7:0] c1,c2;
    wire [16:0] c3;
    wire cclk;
    integer i,cycles=0,last_rise=-1;
    reg ce_sample;
    mini_project_top #(.CLOCK_HZ(1000),.CPU_HZ(10),.DEBOUNCE_CYCLES(3),
        .C1_ACTIVE_LOW(0),.C2_ACTIVE_LOW(0),.C3_ACTIVE_LOW(0)) dut
        (.CLK_50(clk),.T(t),.K(k),.SW1(sw1),.SW2(sw2),.LED(led),.C1(c1),.C2(c2),.C3(c3),.CCLK(cclk));
    // Monitor divider independently: 100 input clocks between CCLK rising edges.
    always @(posedge clk) begin
        cycles=cycles+1;
        ce_sample=dut.step_ce;
        if(dut.reset || dut.slow_clock.fast_selected) last_rise=-1;
        #1;
        if(ce_sample && !dut.slow_clock.fast_selected) begin
            if(cclk!==1) $fatal(1,"CCLK and clock enable are not aligned");
            if(last_rise>=0 && cycles-last_rise!=100) $fatal(1,"CCLK period");
            last_rise=cycles;
        end
    end
    task ticks;
        input integer n;
        begin repeat(n) begin @(posedge clk); #2; end end
    endtask
    task set_data;
        input [7:0] value;
        begin for(i=0;i<8;i=i+1) t[i+1]=value[i]; end
    endtask
    task set_op;
        input [3:0] code;
        begin t[9]=code[3];t[10]=code[2];t[11]=code[1];t[12]=code[0]; end
    endtask
    task press;
        begin @(negedge clk); sw1=1; ticks(12); @(negedge clk); sw1=0; ticks(12); end
    endtask
    function [7:0] led_value;
        input [1:16] bits;
        integer j;
        begin for(j=0;j<8;j=j+1) led_value[j]=bits[j+1]; end
    endfunction
    initial begin
        $dumpfile("build/top.vcd"); $dumpvars(0,tb_top);
        k[4]=1; ticks(5); @(negedge clk); k[4]=0; ticks(10);
        @(negedge clk); k[2]=1; ticks(12);
        @(negedge clk); k[2]=0; ticks(12);
        @(negedge clk); set_data(8'hFC); ticks(16); // A=12, B=15.
        if(c1!==8'hDB || c2!==8'hED || c3!==17'h04B00)
            $fatal(1,"Decimal preview must be 2. and 5. with +, got %h %h %h",c1,c2,c3);
        @(negedge clk); t[11]=1; ticks(16);
        if(c1!==8'h39 || c2!==8'h71) $fatal(1,"Hex input C/F");
        @(negedge clk); t[11]=0; ticks(16);
        // A one-clock bounce is rejected by the three-clock filter.
        @(negedge clk); sw1=1; ticks(1); @(negedge clk); sw1=0; ticks(10);
        if(dut.q1_show) $fatal(1,"SW1 bounce executed");
        @(negedge clk); sw1=1; ticks(220); // Holding SW1 must execute once.
        if(led_value(led)!==11 || led[9]!==1 || c1!==0 || c2!==8'h06 || c3!==17'h00C)
            $fatal(1,"Q1 execution/held button/decimal result");
        @(negedge clk); sw1=0; ticks(12); press;
        if(led_value(led)!==10 || led[9]!==1 || c1!==0 || c3!==17'h00C || c2!==8'h3F)
            $fatal(1,"Q1 low-nibble repeat must show 10 with carry");
        @(negedge clk); sw2=1; set_op(0); set_data(42); ticks(16);
        if(dut.q2.reg_a!==0) $fatal(1,"Q2 default register A");
        // Queue just after a falling CCLK edge, leaving time to observe wait.
        @(negedge cclk); press;
        if(!led[15] || dut.q2.reg_a!==0) $fatal(1,"Q2 must wait for CCLK");
        @(negedge clk); set_data(99); set_op(1); ticks(10);
        @(posedge cclk); #3;
        if(dut.q2.reg_a!==42 || dut.q2.reg_b!==0)
            $fatal(1,"Q2 instruction/data snapshot");
        ticks(2);
        if(c1!==0 || c2!==8'h5B || c3!==17'h38C || led_value(led)!==42) $fatal(1,"Q2 decimal 42 display and binary LEDs");
        if(c3[7]!==1) $fatal(1,"Q2 decimal 42 requires starburst F high");
        @(negedge clk); k[1]=1; ticks(20);
        if(c1!==8'h5B || c2!==8'h77 || c3!==0) $fatal(1,"K1 toggles to hex 2A");
        ticks(120);
        if(!dut.q2_hex_mode) $fatal(1,"Held K1 must not toggle repeatedly");
        @(negedge clk); k[1]=0; ticks(12);
        @(negedge clk); k[1]=1; ticks(12);
        if(dut.q2_hex_mode) $fatal(1,"Second K1 press returns decimal");
        @(negedge clk); k[4]=1; ticks(4);
        if(dut.q2.reg_a!==42 || dut.q1_result!==10 || dut.reset!==0) $fatal(1,"K4 must not reset state");
        $display("PASS top: pin bit order, decimal DP, debounce, mode select, CCLK, queued execution, K1 and ignored K4");
        $finish;
    end
    initial begin #1000000; $fatal(1,"Top test timeout"); end
endmodule
