`timescale 1ns/1ps
// Question 1: unsigned 4-bit calculator with repeated '='.
// Default follows the specified 4-bit ADD/SUB result + separate carry/borrow.
// On repeated '=', the low nibble of the previous result is the new Group-A.
// CHAIN_8BIT=1 optionally keeps all 8 bits for repeated operations ONLY.
module question1 #(
    parameter CHAIN_8BIT = 0,
    parameter EXTERNAL_MATH = 0 // Default: standalone; top can share MUL/DIV.
) (
    input wire clk,
    input wire reset,
    input wire enable,
    input wire execute,
    input wire [3:0] group_a,
    input wire [3:0] group_b,
    input wire [1:0] operator_code,
    output reg [7:0] result,
    output reg carry_borrow,
    output reg error,
    output reg show_result,
    input wire [15:0] math_product,
    input wire [7:0] math_quotient,
    output wire [7:0] math_lhs
);
    reg [3:0] saved_a, saved_b;
    reg [1:0] saved_op;
    wire same_inputs = (group_a == saved_a) && (group_b == saved_b) &&
                       (operator_code == saved_op);
    wire repeat_op = show_result && same_inputs;
    wire wide_op = CHAIN_8BIT && repeat_op;
    wire [7:0] lhs = repeat_op ? (wide_op ? result : {4'b0, result[3:0]})
                                      : {4'b0, group_a};
    wire [7:0] rhs = {4'b0, group_b};
    assign math_lhs = lhs;
    reg [7:0] next_result;
    reg next_carry, next_error;
    // Constant width specializes the default design to a real 4-bit datapath.
    localparam WIDTH = CHAIN_8BIT ? 8 : 4;
    wire subtract = (operator_code == 2'b01);
    wire [WIDTH:0] sum_diff = {1'b0,lhs[WIDTH-1:0]} +
        {1'b0,(rhs[WIDTH-1:0] ^ {WIDTH{subtract}})} + subtract;
    (* multstyle = "dsp" *) wire [11:0] product;
    wire [WIDTH-1:0] quotient;
    generate if (EXTERNAL_MATH) begin: shared_math
        assign product = math_product[11:0];
        assign quotient = math_quotient[WIDTH-1:0];
    end else begin: local_math
        assign product = lhs[WIDTH-1:0] * group_b;
        assign quotient = lhs[WIDTH-1:0] / group_b;
    end endgenerate
    always @* begin
        next_result = result;
        next_carry = 0;
        next_error = 0;
        case (operator_code)
            2'b00: begin
                next_result = wide_op ? sum_diff : {4'b0, sum_diff[3:0]};
                next_carry = wide_op ? sum_diff[WIDTH] : sum_diff[4];
            end
            2'b01: begin
                next_result = wide_op ? sum_diff : {4'b0, sum_diff[3:0]};
                next_carry = ~sum_diff[WIDTH];
            end
            2'b10: begin
                next_result = product[7:0];
                next_carry = wide_op && (product[11:8] != 0);
            end
            2'b11: begin
                if (rhs == 0) next_error = 1;
                else next_result = quotient; // Unsigned integer quotient.
            end
        endcase
    end
    always @(posedge clk) begin
        if (reset) begin
            result <= 0;
            carry_borrow <= 0;
            error <= 0;
            show_result <= 0;
            saved_a <= 0;
            saved_b <= 0;
            saved_op <= 0;
        end else if (enable) begin
            // Loading an unchanged value is equivalent to holding it; avoid
            // a separate equality/execute-controlled enable for these bits.
            saved_a <= group_a;
            saved_b <= group_b;
            saved_op <= operator_code;
            if (!same_inputs) begin
                show_result <= 0;
            end
            if (execute) begin
                result <= next_result;
                carry_borrow <= next_carry;
                error <= next_error;
                show_result <= 1;
            end
        end
    end
endmodule
