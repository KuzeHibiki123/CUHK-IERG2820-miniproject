`timescale 1ns/1ps
// Question 2: three 8-bit registers, all 16 instruction codes.
// SW1's one-clock pulse queues an instruction and its data. Commit on step_ce.
// One pending slot: while busy, further pulses are ignored, except on a commit
// edge where the old instruction commits and the new pulse refills the slot.
module question2 #(
    parameter EXTERNAL_MATH = 0
) (
    input wire clk,
    input wire reset,
    input wire enable,
    input wire step_ce,
    input wire execute,
    input wire [7:0] data_in,
    input wire [3:0] opcode,
    output reg [7:0] reg_a,
    output reg [7:0] reg_b,
    output reg [7:0] reg_c,
    output reg [7:0] result,
    output reg carry_borrow,
    output wire zero,
    output reg error,
    output wire [7:0] display_value,
    output reg busy,
    input wire [15:0] math_product,
    input wire [7:0] math_quotient
);
    reg [1:0] display_select;
    reg [7:0] pending_data;
    reg [3:0] pending_op;
    wire commit = enable && step_ce && (busy || execute);
    wire [3:0] current_op = busy ? pending_op : opcode;
    wire [7:0] current_data = busy ? pending_data : data_in;
    reg [7:0] new_result;
    reg new_carry, new_error;
    wire [7:0] operand = current_op[0] ? reg_c : reg_b;
    wire subtract = current_op[1]; // ADD=010x; SUB=011x.
    wire [8:0] sum_diff = {1'b0,reg_a} +
        {1'b0,(operand ^ {8{subtract}})} + subtract;
    wire [15:0] product;
    wire [7:0] quotient;
    generate if (EXTERNAL_MATH) begin: shared_math
        assign product = math_product;
        assign quotient = math_quotient;
    end else begin: local_math
        assign product = reg_a * reg_b;
        assign quotient = reg_a / reg_b;
    end endgenerate
    assign display_value = (display_select == 1) ? reg_b :
                           (display_select == 2) ? reg_c : reg_a;
    // One zero detector shared by every instruction result.
    assign zero = (result == 0);
    always @* begin
        // Register write enables preserve OUT/NOP status. Feedback is not
        // needed in these combinational muxes when the write is disabled.
        new_result = 0;
        new_carry = 0;
        new_error = 0;
        case (current_op)
            4'h0, 4'h1, 4'h2: new_result = current_data;
            4'h3: new_result = ~reg_a;
            4'h4, 4'h5, 4'h6, 4'h7: begin
                new_result = sum_diff[7:0];
                new_carry = sum_diff[8] ^ subtract;
            end
            4'h8: begin
                new_result = product[7:0];
                new_carry = (product[15:8] != 0);
            end
            4'h9: begin
                new_result = reg_a;
                if (reg_b == 0) new_error = 1;
                else new_result = quotient;
            end
            4'hA: begin
                new_result = {reg_a[6:0], 1'b0}; // Logical shift, not rotate.
                new_carry = reg_a[7];
            end
            4'hB: begin
                new_result = {1'b0, reg_a[7:1]};
                new_carry = reg_a[0];
            end
            4'hC: new_result = reg_a;
            4'hD: new_result = reg_b;
            4'hE: new_result = reg_c;
            default: begin end // 1111 NOP: preserve all architectural state.
        endcase
    end
    always @(posedge clk) begin
        if (reset) begin
            reg_a <= 0;
            reg_b <= 0;
            reg_c <= 0;
            result <= 0;
            carry_borrow <= 0;
            error <= 0;
            display_select <= 0;
            busy <= 0;
        end else begin
            if (!enable) busy <= 0;
            else if (commit) begin
                // Retain a newly arriving command if the old slot commits.
                busy <= busy && execute;
            end else if (execute && !busy) begin
                busy <= 1;
            end
            if (commit) begin
                // Explicit write enables avoid routing every operation through
                // separate A/B/C feedback multiplexers.
                if (current_op == 0 || (current_op >= 3 && current_op < 12))
                    reg_a <= new_result;
                if (current_op == 1) reg_b <= current_data;
                else if (current_op == 8) reg_b <= product[15:8];
                if (current_op == 2) reg_c <= current_data;
                if (current_op >= 12 && current_op < 15)
                    display_select <= current_op[1:0];
                if (current_op < 12) begin
                    carry_borrow <= new_carry;
                    error <= new_error;
                end
                if (current_op != 4'hF) begin
                    result <= new_result;
                end
            end
        end
    end
    // Payload is unobservable while busy=0, so it needs no reset network.
    // Capture on an empty slot or simultaneous commit/refill.
    always @(posedge clk) begin
        if (!reset && enable && execute && (!busy || step_ce)) begin
            pending_data <= data_in;
            pending_op <= opcode;
        end
    end
endmodule
