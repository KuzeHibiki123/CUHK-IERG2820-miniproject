`timescale 1ns/1ps
module c1_display #(
    parameter ACTIVE_LOW = 1
) (
    input wire [3:0] digit,
    input wire blank,
    input wire decimal_point,
    output wire [7:0] seg
);
    wire [6:0] decoded;
    wire [7:0] lit;
    hex7_decoder decoder (.digit(digit), .seg_on(decoded));
    assign lit = blank ? 8'b0 : {decimal_point, decoded};
    assign seg = ACTIVE_LOW ? ~lit : lit;
endmodule
