`timescale 1ns/1ps
module digit_display_rom #(
    parameter LEFT_DIGIT = 1,
    parameter ACTIVE_LOW = 1
) (
    input wire clk, reset,
    input wire [7:0] value,
    input wire hex_mode, preview,
    output wire [7:0] seg
);
    function [6:0] glyph;
        input integer d;
        begin
            case(d)
                0:glyph=7'h3f; 1:glyph=7'h06; 2:glyph=7'h5b; 3:glyph=7'h4f;
                4:glyph=7'h66; 5:glyph=7'h6d; 6:glyph=7'h7d; 7:glyph=7'h07;
                8:glyph=7'h7f; 9:glyph=7'h6f; 10:glyph=7'h77; 11:glyph=7'h7c;
                12:glyph=7'h39; 13:glyph=7'h5e; 14:glyph=7'h79; 15:glyph=7'h71;
                default:glyph=0;
            endcase
        end
    endfunction
    (* ramstyle = "M9K" *) reg [7:0] table_data [0:1023];
    integer a,v,d;
    reg [7:0] lit;
    initial begin
        for(a=0;a<1024;a=a+1) begin
            v=a%256;
            if(a>=512) begin 
                d=LEFT_DIGIT ? v%16 : v/16;
                lit={1'b0,glyph(((a/256)%2==0) ? d%10 : d)};
                if((a/256)%2==0 && d>=10) lit[7]=1;
            end else if(a>=256) begin
                d=LEFT_DIGIT ? v/16 : v%16;
                lit={1'b0,glyph(d)};
            end else begin
                d=LEFT_DIGIT ? v/100 : v%10;
                lit=(LEFT_DIGIT && v<100) ? 8'b0 : {1'b0,glyph(d)};
            end
            table_data[a]=ACTIVE_LOW ? ~lit : lit;
        end
    end
    reg [7:0] rom_data;
    reg reset_q;
    always @(posedge clk) begin
        rom_data <= table_data[{preview,hex_mode,value}];
        reset_q <= reset;
    end
    assign seg=reset_q ? (ACTIVE_LOW ? 8'hff : 8'h00) : rom_data;
endmodule

module c1_registered_display #(parameter ACTIVE_LOW=1) (
    input wire clk,reset,
    input wire [7:0] value,
    input wire hex_mode,preview,
    output wire [7:0] seg
);
    digit_display_rom #(.LEFT_DIGIT(1),.ACTIVE_LOW(ACTIVE_LOW)) rom
        (clk,reset,value,hex_mode,preview,seg);
endmodule

module c2_registered_display #(parameter ACTIVE_LOW=1) (
    input wire clk,reset,
    input wire [7:0] value,
    input wire hex_mode,preview,
    output wire [7:0] seg
);
    digit_display_rom #(.LEFT_DIGIT(0),.ACTIVE_LOW(ACTIVE_LOW)) rom
        (clk,reset,value,hex_mode,preview,seg);
endmodule

module c3_registered_display #(parameter ACTIVE_LOW=1) (
    input wire clk,reset,
    input wire [7:0] value,
    input wire hex_mode,preview,
    input wire [1:0] operator_code,
    output wire [16:0] seg
);
    (* ramstyle = "M9K" *) reg [15:0] table_data [0:511];
    integer a,d;
    reg [6:0] seven;
    reg [15:0] lit;
    initial begin
        for(a=0;a<512;a=a+1) begin
            lit=0;
            if(a>=10 && a<256) begin
                d=(a/10)%10;
                case(d)
                    0:seven=7'h3f; 1:seven=7'h06; 2:seven=7'h5b; 3:seven=7'h4f;
                    4:seven=7'h66; 5:seven=7'h6d; 6:seven=7'h7d; 7:seven=7'h07;
                    8:seven=7'h7f; default:seven=7'h6f;
                endcase
                lit[9:0]={seven[6],seven[6],seven[5:4],seven[3],seven[3],seven[2:1],seven[0],seven[0]};
            end else case(a)
                256:lit=16'h4b00; 257:lit=16'h0300;
                258:lit=16'hb400; 259:lit=16'h9000;
                default:lit=0;
            endcase
            table_data[a]=ACTIVE_LOW ? ~lit : lit;
        end
    end
    wire [8:0] address=preview ? {7'b1000000,operator_code} :
                             hex_mode ? 9'd260 : {1'b0,value};
    reg [15:0] rom_data;
    reg reset_q;
    always @(posedge clk) begin
        rom_data<=table_data[address];
        reset_q<=reset;
    end
    assign seg={ACTIVE_LOW!=0, reset_q ? (ACTIVE_LOW ? 16'hffff : 16'h0000) : rom_data};
endmodule
