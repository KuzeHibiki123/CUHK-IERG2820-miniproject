`timescale 1ns/1ps
module c3_display #(
    parameter ACTIVE_LOW = 1
) (
    input wire [3:0] digit,
    input wire blank,
    input wire decimal_point,
    input wire operator_mode,
    input wire [1:0] operator_code,
    output wire [16:0] seg
);
    wire [6:0] decoded;
    reg [16:0] lit;
    hex7_decoder decoder (.digit(digit), .seg_on(decoded));
    always @* begin
        lit = 17'b0;
        if (!blank) begin
            if (operator_mode) begin
                case (operator_code)
                    2'b00: lit = 17'h04B00; 
                    2'b01: lit = 17'h00300; 
                    2'b10: lit = 17'h0B400; 
                    2'b11: lit = 17'h09000; 
                endcase
            end else begin
                lit[1:0] = {2{decoded[0]}}; 
                lit[2] = decoded[1];      
                lit[3] = decoded[2];      
                lit[5:4] = {2{decoded[3]}}; 
                lit[6] = decoded[4];  
                lit[7] = decoded[5];
                lit[9:8] = {2{decoded[6]}}; 
            end
            lit[16] = decimal_point;
        end
    end
    assign seg = ACTIVE_LOW ? ~lit : lit;
endmodule
