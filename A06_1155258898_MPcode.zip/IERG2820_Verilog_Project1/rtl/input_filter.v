
`timescale 1ns/1ps

module input_filter #(
    parameter WIDTH = 1,
    parameter STABLE_CYCLES = 500000
) (
    input  wire                 clk,
    input  wire                 reset,
    input  wire [WIDTH-1:0]     async_in,
    output reg  [WIDTH-1:0]     level,
    output reg  [WIDTH-1:0]     rise
);

    localparam COUNT_WIDTH =
        (STABLE_CYCLES < 2) ? 1 : $clog2(STABLE_CYCLES);

    (* altera_attribute = "-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS" *)
    reg [WIDTH-1:0] sync1, sync2;

    always @(posedge clk) begin
        if (reset) begin
            sync1 <= 0;
            sync2 <= 0;
        end else begin
            sync1 <= async_in;
            sync2 <= sync1;
        end
    end

    generate
        if (STABLE_CYCLES <= 1) begin : immediate

            always @(posedge clk) begin
                if (reset) begin
                    level <= 0;
                    rise  <= 0;
                end else begin
                    level <= sync2;
                    rise  <= sync2 & ~level;
                end
            end

        end else if (WIDTH == 1) begin : single_bit

            reg [COUNT_WIDTH-1:0] count;

            always @(posedge clk) begin
                if (reset) begin
                    count <= 0;
                    level <= 0;
                    rise  <= 0;
                end else begin
                    rise <= 0;

                    if (sync2 == level || count == STABLE_CYCLES-1) begin
                        count <= 0;
                    end else begin
                        count <= count + 1'b1;
                    end

                    if (sync2 != level && count == STABLE_CYCLES-1) begin
                        level <= sync2;
                        rise  <= sync2 & ~level;
                    end
                end
            end

        end else begin : bus_input

            reg [WIDTH-1:0] candidate;
            reg [COUNT_WIDTH-1:0] count;

            always @(posedge clk) begin
                if (reset) begin
                    candidate <= 0;
                    count     <= 0;
                    level     <= 0;
                    rise      <= 0;
                end else begin
                    candidate <= sync2;
                    rise      <= 0;

                    if (sync2 != candidate) begin
                        count <= 1;
                    end else begin
                        count <= count + 1'b1;
                    end

                    if (sync2 == candidate &&
                        count == STABLE_CYCLES-1) begin
                        level <= sync2;
                        rise  <= sync2 & ~level;
                    end
                end
            end

        end
    endgenerate

endmodule
