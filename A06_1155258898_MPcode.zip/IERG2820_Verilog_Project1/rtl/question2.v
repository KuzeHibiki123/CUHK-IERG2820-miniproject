`timescale 1ns/1ps
module question2 #(
    parameter EXTERNAL_MATH = 0
) (
    input wire clk,
    input wire reset,
    input wire enable,
    input wire step_ce,
    input wire execute,
    input wire [7:0] data_in,
    input wire [3:0] opcode,
    output reg [7:0] reg_a,
    output reg [7:0] reg_b,
    output reg [7:0] reg_c,
    output reg [7:0] result,
    output reg carry_borrow,
    output wire zero,
    output reg error,
    output wire [7:0] display_value,
    output reg busy,
    input wire [15:0] math_product,
    input wire [7:0] math_quotient
);
    reg [1:0] display_select;
    reg [7:0] pending_data;
    reg [3:0] pending_op;
    wire commit = enable && step_ce && (busy || execute);
    wire [3:0] current_op = busy ? pending_op : opcode;
    wire [7:0] current_data = busy ? pending_data : data_in;
    reg [7:0] new_result;
    reg [7:0] next_a;
    reg new_carry, new_error;
    wire [7:0] operand = current_op[0] ? reg_c : reg_b;
    wire subtract = current_op[1];
    wire [8:0] sum_diff = {1'b0,reg_a} +
        {1'b0,(operand ^ {8{subtract}})} + subtract;
    wire [15:0] product;
    wire [7:0] quotient;
    generate if (EXTERNAL_MATH) begin: shared_math
        assign product = math_product;
        assign quotient = math_quotient;
    end else begin: local_math
        assign product = reg_a * reg_b;
        assign quotient = reg_a / reg_b;
    end endgenerate
    assign display_value = (display_select == 1) ? reg_b :
                           (display_select == 2) ? reg_c : reg_a;
    assign zero = (result == 0);
    always @* begin
        new_result = 0;
        new_carry = 0;
        new_error = 0;
        case (current_op)
            4'h0, 4'h1, 4'h2: new_result = current_data;
            4'h3: new_result = ~reg_a;
            4'h4, 4'h5, 4'h6, 4'h7: begin
                new_result = sum_diff[7:0];
                new_carry = sum_diff[8] ^ subtract;
            end
            4'h8: begin
                new_result = product[7:0];
                new_carry = (product[15:8] != 0);
            end
            4'h9: begin
                new_result = reg_a;
                if (reg_b == 0) new_error = 1;
                else new_result = quotient;
            end
            4'hA: begin
                new_result = {reg_a[6:0], 1'b0}; 
                new_carry = reg_a[7];
            end
            4'hB: begin
                new_result = {1'b0, reg_a[7:1]};
                new_carry = reg_a[0];
            end
            4'hC: new_result = reg_a;
            4'hD: new_result = reg_b;
            4'hE: new_result = reg_c;
            default: begin end 
        endcase
    end
    always @* begin
        case (current_op)
            4'h0: next_a = current_data;
            4'h3: next_a = ~reg_a;
            4'h4,4'h5,4'h6,4'h7: next_a = sum_diff[7:0];
            4'h8: next_a = product[7:0];
            4'h9: next_a = quotient;
            4'hA: next_a = {reg_a[6:0],1'b0};
            4'hB: next_a = {1'b0,reg_a[7:1]};
            default: next_a = 8'bx;
        endcase
    end
    always @(posedge clk) begin
        if (reset) begin
            reg_a <= 0;
            reg_b <= 0;
            reg_c <= 0;
            result <= 0;
            carry_borrow <= 0;
            error <= 0;
            display_select <= 0;
            busy <= 0;
        end else begin
            if (!enable) busy <= 0;
            else if (commit) begin
                busy <= busy && execute;
            end else if (execute && !busy) begin
                busy <= 1;
            end
            if (commit) begin
                if ((current_op == 0 || (current_op >= 3 && current_op < 12)) &&
                    !(current_op == 9 && reg_b == 0))
                    reg_a <= next_a;
                if (current_op == 1) reg_b <= current_data;
                else if (current_op == 8) reg_b <= product[15:8];
                if (current_op == 2) reg_c <= current_data;
                if (current_op >= 12 && current_op < 15)
                    display_select <= current_op[1:0];
                if (current_op < 12) begin
                    carry_borrow <= new_carry;
                    error <= new_error;
                end
                if (current_op != 4'hF) begin
                    result <= new_result;
                end
            end
        end
    end
    always @(posedge clk) begin
        if (!busy || step_ce) begin
            pending_data <= data_in;
            pending_op <= opcode;
        end
    end
endmodule
