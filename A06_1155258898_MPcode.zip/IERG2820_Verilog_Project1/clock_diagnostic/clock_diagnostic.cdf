JedecChain;
 FileRevision(JESD32A);
 DefaultMfr(6E);
 P ActionCode(Cfg)
 Device PartName(EP4CE6E22) Path("C:/Users/wangb/Documents/Mini_Project/IERG2820_Verilog_Project1/clock_diagnostic/output_files/") File("clock_diagnostic.sof") MfrSpec(OpMask(1));
ChainEnd;
AlteraBegin;
 ChainType(JTAG);
AlteraEnd;
