`timescale 1ns/1ps
// Temporary board diagnosis. Static segments do not depend on clock or K4.
module clock_diagnostic #(
    parameter CLOCK_HZ=50000000,
    parameter DEBOUNCE_CYCLES=500000
) (
    input wire CLK_50,
    input wire [1:12] T,
    input wire [1:4] K,
    input wire SW1, SW2,
    output wire [1:16] LED,
    output wire [7:0] C1, C2,
    output wire [16:0] C3,
    output wire CCLK
);
    reg [1:0] boot=2'b11;
    always @(posedge CLK_50) boot <= {boot[0],1'b0};
    wire reset=boot[1];
    wire k2_pulse;
    reg slow_mode=0;
    input_filter #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) filter_k2
        (.clk(CLK_50),.reset(reset),.async_in(K[2]),.level(),.rise(k2_pulse));
    always @(posedge CLK_50) begin
        if(reset) slow_mode<=0;
        else if(k2_pulse) slow_mode<=~slow_mode;
    end
    wire heartbeat, unused_ce;
    clock_enable #(.CLOCK_HZ(CLOCK_HZ),.STEP_HZ(1)) heartbeat_divider
        (.clk(CLK_50),.reset(reset),.cclk(heartbeat),.step_ce());
    selectable_clock_enable #(.CLOCK_HZ(CLOCK_HZ),.STEP_HZ(1)) selected_clock
        (.clk(CLK_50),.reset(reset),.slow_mode(slow_mode),.cclk(CCLK),.step_ce(unused_ce));
    assign C1=8'h7F;
    assign C2=8'h7F;
    assign C3=17'h003FF;
    assign LED[1]=heartbeat; // Always 1 Hz if the 50 MHz source is present.
    assign LED[2]=K[2];      // Raw K2, independent of the clock.
    assign LED[3]=K[4];      // Raw K4, independent of the clock.
    assign LED[4]=slow_mode;
    assign LED[5]=reset;     // Remains on if no input clock releases boot.
    assign LED[6]=1'b1;     // Static configuration/output check.
    assign LED[7:16]=10'b0;
endmodule
