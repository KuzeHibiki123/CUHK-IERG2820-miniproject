`timescale 1ns/1ps
module tb_clock_diagnostic;
 reg clk=0,run_clock=0;
 always #10 if(run_clock) clk=~clk;
 reg [1:4] k=0;
 wire [1:16] led;wire [7:0] c1,c2;wire [16:0] c3;wire cc;
 clock_diagnostic #(.CLOCK_HZ(100),.DEBOUNCE_CYCLES(3)) dut
 (clk,12'b0,k,1'b0,1'b0,led,c1,c2,c3,cc);
 task ticks;input integer n;begin repeat(n)begin @(posedge clk);#2;end end endtask
 integer edges=0;
 always @(posedge led[1]) edges=edges+1;
 initial begin
  #50;
  if(c1!==8'h7F||c2!==8'h7F||c3!==17'h003FF||led[6]!==1||led[5]!==1)
    $fatal(1,"Static outputs must work without clock");
  k[2]=1;k[4]=1;#10;
  if(led[2]!==1||led[3]!==1)$fatal(1,"Raw keys must work without clock");
  k=0;run_clock=1;ticks(220);
  if(edges!=2||led[5]!==0||led[4]!==0)$fatal(1,"Heartbeat/default mode");
  @(negedge clk);k[2]=1;ticks(12);
  if(led[4]!==1)$fatal(1,"K2 switch");
  ticks(150);if(led[4]!==1)$fatal(1,"Held K2 repeated");
  @(negedge clk);k[4]=1;ticks(12);
  if(c1!==8'h7F||led[3]!==1||led[4]!==1)$fatal(1,"Diagnostic K4 must not blank or reset");
  @(negedge clk);k[2]=0;ticks(12);@(negedge clk);k[2]=1;ticks(12);
  if(led[4]!==0)$fatal(1,"Return fast");
  $display("PASS diagnostic: static displays without clock, raw keys, heartbeat, K2 toggle, K4 isolation");
  $finish;
 end
 initial begin #20000;$fatal(1,"Timeout");end
endmodule
