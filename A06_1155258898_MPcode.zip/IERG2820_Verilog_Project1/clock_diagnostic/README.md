# Missing display / CCLK diagnosis

Temporary hardware diagnostic; the main project's RTL, QSF and SOF are unchanged.
Open `clock_diagnostic.cdf` in Programmer, or add
`output_files/clock_diagnostic.sof`. Confirm Program/Configure is checked and
programming reaches 100% Successful. All 62 explicit pin assignments are copied
from the current main project and checked against the diagnostic fitter report.

Keep the original 50 MHz source connected to PIN_24. PIN_141 is an OUTPUT to
the scope, not a replacement clock input. Use the board ground for the probe.

Expected observations (active high):

| Output | Meaning |
|---|---|
| C1/C3/C2 | Static 8/8/8, independent of clock and K4. The known damaged F segment may remain dark. |
| LED6 | Always on, independent of clock and keys. |
| LED1 | Always blinks at 1 Hz with a working 50 MHz input, regardless of K2. |
| LED2 | Raw K2 level: on while pressed, off when released. |
| LED3 | Raw K4 level: on while pressed, off when released. |
| LED4 | Off = selected 50 MHz, on = selected 1 Hz. K2 toggles once per press. |
| LED5 | Power-up reset: normally turns off after two input clock edges. Stays on without input clock at startup. |
| PIN_141 | Default 50 MHz; press and release K2 to select 1 Hz (0.5 s high / 0.5 s low). |

Unlike the main project, this diagnostic intentionally ignores K4 as a reset
and only reports its level. A stuck-high K4 can therefore be identified without
blanking the displays. K2 is synchronized and debounced as in the main project.

Interpretation:

- Static 8s and LED6 also absent: first check successful programming, power,
  display common connections and physical output wiring.
- Static outputs present but LED1 never blinks: verify the actual waveform
  on PIN_24 and LED1's connection; an attached clock wire alone does not prove
  that a valid 50 MHz signal reaches the FPGA.
- LED3 remains on with K4 released: the main project would be held in reset.
- LED1 blinks but LED2 does not follow K2: check K2/PIN_101 wiring and level.
- LED2 follows K2 but LED4 does not toggle: report that result for further
  input-filter investigation. Allow at least 10 ms per touch and release.
- LED4 is on but PIN_141 has no 1 Hz waveform: inspect the probe/ground and
  physical PIN_141 connection; report LED1/LED4 states and the measured level.

Simulation passes for missing clock, static outputs, raw key observation,
heartbeat, held K2, mode toggle and K4 isolation. Quartus full compile passes
with zero errors. All nine internal timing checks pass; worst setup slack
6.926 ns. Warnings include deliberately constant outputs, unused inputs and
existing unspecified I/O details. Board I/O delays are not constrained.
This session has not programmed or measured the physical board.
